package com.cg.ams.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	 private int TRANSACTION_ID;
	 private int acc_no;
	 private String DATE_AND_TIME;                                      
	 private String TRANCATION_TYPE;                                    
	 private Double AMOUNT;
	 private String TRANSACTION_STATUS;
	
	
	public int getTRANSACTION_ID() {
		return TRANSACTION_ID;
	}
	public void setTRANSACTION_ID(int tRANSACTION_ID) {
		TRANSACTION_ID = tRANSACTION_ID;
	}
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public String getDATE_AND_TIME() {
		return DATE_AND_TIME;
	}
	public void setDATE_AND_TIME(String dATE_AND_TIME) {
		DATE_AND_TIME = dATE_AND_TIME;
	}
	public String getTRANCATION_TYPE() {
		return TRANCATION_TYPE;
	}
	public void setTRANCATION_TYPE(String tRANCATION_TYPE) {
		TRANCATION_TYPE = tRANCATION_TYPE;
	}
	public Double getAMOUNT() {
		return AMOUNT;
	}
	public void setAMOUNT(Double aMOUNT) {
		AMOUNT = aMOUNT;
	}
	public String getTRANSACTION_STATUS() {
		return TRANSACTION_STATUS;
	}
	public void setTRANSACTION_STATUS(String tRANSACTION_STATUS) {
		TRANSACTION_STATUS = tRANSACTION_STATUS;
	}

	
	@Override
	public String toString() {
		return "BankTransaction [TRANSACTION_ID=" + TRANSACTION_ID + ", acc_no=" + acc_no + ", DATE_AND_TIME="
				+ DATE_AND_TIME + ", TRANCATION_TYPE=" + TRANCATION_TYPE + ", AMOUNT=" + AMOUNT
				+ ", TRANSACTION_STATUS=" + TRANSACTION_STATUS + "]";
	}
	
	public Transaction() {
		super();
	}
	
	public Transaction(int tRANSACTION_ID, int acc_no, String dATE_AND_TIME, String tRANCATION_TYPE, Double aMOUNT,
			String tRANSACTION_STATUS) {
		super();
		TRANSACTION_ID = tRANSACTION_ID;
		this.acc_no = acc_no;
		DATE_AND_TIME = dATE_AND_TIME;
		TRANCATION_TYPE = tRANCATION_TYPE;
		AMOUNT = aMOUNT;
		TRANSACTION_STATUS = tRANSACTION_STATUS;
	}
}
