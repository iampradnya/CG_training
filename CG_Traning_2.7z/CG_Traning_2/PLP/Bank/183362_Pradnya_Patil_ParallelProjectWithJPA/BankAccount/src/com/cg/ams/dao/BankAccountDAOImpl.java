package com.cg.ams.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.ams.dto.BankAccount;
import com.cg.ams.dto.Transaction;
import com.cg.ams.exception.BankAccountException;


/**
 * Author name:Pradnya Patil
 * @author ppati100
 *Mail Id:pradnya.f.patil@capgemini.com
 *Version:1.0
 *Description:Dao class to perform CRUD operations on hashmap
 *Date:!07-august-2019
 * @param <EntityManager>
 */



public class BankAccountDAOImpl implements BankAccountDAO 
{

	
//	
//	private static Map<Integer,BankAccount> accounts=new HashMap<>();

	static EntityManagerFactory entityManagerFactory;
	static EntityManager entityManager;
	
	public BankAccountDAOImpl(){
//		entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
//		entityManager=entityManagerFactory.createEntityManager();
		entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
		entityManager=entityManagerFactory.createEntityManager();
	
	}

	


	//method declaration of interface
	@Override
	public BankAccount addAccount(BankAccount ba) throws BankAccountException, SQLException, IOException 
	{

		entityManager.getTransaction().begin();
		entityManager.persist(ba);
		entityManager.getTransaction().commit();
		System.out.println(" record inserted successfully");
		System.out.println("Customer added");
		System.out.println("Account number is "+ba.getAcc_no());
		
		
		return ba;
	}



	@Override
	public boolean depositAmount(double amount, int accno) throws BankAccountException, IOException, SQLException 
	{
		BankAccount bankaccount= new BankAccount();
		bankaccount=entityManager.find(BankAccount.class,accno);
		double current_balance=showBalance(accno);
		double new_balance=current_balance+amount;
		bankaccount.setBalance(new_balance);
		entityManager.getTransaction().begin();
		entityManager.merge(bankaccount);
		entityManager.getTransaction().commit();

		saveTransaction(accno,"Deposit", amount,"Deposit Successfull");
		return true;

	}



	




	@Override
	public boolean withdrawAmount(double amount, int accno) throws BankAccountException, IOException, SQLException 
	{
		BankAccount bankaccount= new BankAccount();
		bankaccount=entityManager.find(BankAccount.class,accno);
		
		double current_balance=showBalance(accno);
		double new_balance=current_balance-amount;
		bankaccount.setBalance(new_balance);
		
		
		
		
		if(current_balance>amount) 
		{
			
			entityManager.getTransaction().begin();
			entityManager.merge(bankaccount);
			entityManager.getTransaction().commit();
			saveTransaction(accno,"Withdraw",amount,"Withdraw Successfull");
			return true;
		}
		
		else 
		{
			throw new BankAccountException("Not Enough Amount");
		}
	}



	@Override
	public boolean fundTransfer(double amount, int fromacc, int toacc)
			throws BankAccountException, IOException, SQLException {

		if(withdrawAmount(amount, fromacc) && depositAmount(amount, toacc))
		{
			return true;
		}
		return false;


		}
	
	


	@Override
	public double showBalance(int accno) throws BankAccountException, IOException, SQLException 
	{
		BankAccount bankaccount= new BankAccount();
//		System.out.println("HGanesh");
//		System.out.println(accno);
////		TypedQuery<BankAccount> tq=entityManager.createQuery("select account from BankAccount account where account.acc_no=:accno",BankAccount.class);
////		tq.setParameter("accno", accno);
//		
		bankaccount=entityManager.find(BankAccount.class,accno);
		if(bankaccount==null)
		{
			throw new BankAccountException("account does not exist");
		}
		
		double balance=bankaccount.getBalance();
		
		return balance;

	}






	@Override
	public void printTransactions(int accno) throws BankAccountException, SQLException, IOException {

		
		entityManager.getTransaction().begin();
		TypedQuery<Transaction> transactionQuery=entityManager.createQuery("select transaction from Transaction transaction where transaction.acc_no=:accno",Transaction.class);
		transactionQuery.setParameter("accno", accno);
		List<Transaction> list=transactionQuery.getResultList();
		for(Transaction transaction:list)
		{
			System.out.println(transaction);
		}
		entityManager.getTransaction().commit();
		
	}




	public void saveTransaction(int accno, String history, double amount, String status) throws BankAccountException, IOException {

		String s=gettime();
		System.out.println(s);
	
		
		Transaction banktransaction=new Transaction();
		banktransaction.setDATE_AND_TIME(s);
		banktransaction.setAcc_no(accno);
		banktransaction.setAMOUNT(amount);
		banktransaction.setTRANCATION_TYPE(history);
		banktransaction.setTRANSACTION_STATUS(status);
		
		entityManager.getTransaction().begin();
		entityManager.persist(banktransaction);
		entityManager.getTransaction().commit();

	}



	private String gettime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();
		String a=dtf.format(now);
		return a;

	}



	@Override
	public boolean checkAccno(int accno) throws BankAccountException, SQLException, IOException {
		boolean check = false;

		entityManager.getTransaction().begin();
		TypedQuery<BankAccount> transactionQuery=entityManager.createQuery("select account from BankAccount account where account.acc_no=:accno",BankAccount.class);
		transactionQuery.setParameter("accno", accno);
		
		
		List<BankAccount> list=transactionQuery.getResultList();
		entityManager.getTransaction().commit();
		if(list==null) {
			
			return false;
		}else
		{
			System.out.println(list);
			return true;
		}
		
		
	



	}

}
