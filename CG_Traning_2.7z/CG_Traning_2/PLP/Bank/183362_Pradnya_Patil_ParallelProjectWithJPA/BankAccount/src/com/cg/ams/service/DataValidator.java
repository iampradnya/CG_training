package com.cg.ams.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator 
{
	public boolean validateAccNo(int accno)
	{
		Pattern pattern=Pattern.compile("[0-9]{6,}");
		Matcher m=pattern.matcher(Integer.toString(accno));
		return m.matches();
	}
	
	public boolean validateAmount(double amt)
	{
		Pattern pattern=Pattern.compile("[0-9.]{3,}");
		Matcher m=pattern.matcher(Double.toString(amt));
		return m.matches();
	}
	
	public boolean validateName(String name)
	{
		Pattern pattern=Pattern.compile("[A-Z]{1}[a-z ]{2,}");
		Matcher m=pattern.matcher(name);
		return m.matches();
	}
	
	public boolean validatePhoneNo(String phone_no)
	{
		Pattern pattern=Pattern.compile("[7-9]{1}[0-9]{9}");
		Matcher m=pattern.matcher(phone_no);
		return m.matches();
	}
}
