package com.cg.ams.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.ams.dao.BankAccountDAO;
import com.cg.ams.dao.BankAccountDAOImpl;
import com.cg.ams.dto.BankAccount;
import com.cg.ams.exception.BankAccountException;

public class BankAccountServiceImpl implements BankAccountService 

{
	DataValidator validator;//declaring the variables
	BankAccountDAO dao;
	public BankAccountServiceImpl() 
	{
		validator=new DataValidator();//initialization of the variables
		dao=new BankAccountDAOImpl();
	}
	
	
	//method declaration of interface
	@Override
	public BankAccount addAccount(BankAccount ba) throws BankAccountException, SQLException, IOException 
	{
		if(!validator.validateName(ba.get_name()))
		{
			try
			{
				throw new BankAccountException("Invalid Name");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validatePhoneNo(ba.getPhone_no()))
		{
			try
			{
				throw new BankAccountException("Invalid Phone Number");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		return dao.addAccount(ba);
	}

	
	
	@Override
	public boolean depositAmount(double amount, int accno) throws BankAccountException, IOException, SQLException 
	{
		if(!validator.validateAmount(amount))
		{
			try
			{
				throw new BankAccountException("Invalid amount"
						+ "(should be in decimal)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(accno))
		{
			try
			{
				throw new BankAccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		return dao.depositAmount(amount, accno);
	}

	
	
	@Override
	public boolean withdrawAmount(double amount, int accno) throws BankAccountException, IOException, SQLException 
	{
		if(!validator.validateAmount(amount))
		{
			try
			{
				throw new BankAccountException("Invalid amount"
						+ "(should be in decimal)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(accno))
		{
			try
			{
				throw new BankAccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		return dao.withdrawAmount(amount, accno);
	}

	
	
	@Override
	public boolean fundTransfer(double amount, int fromacc, int toacc) throws BankAccountException, IOException, SQLException 
	{
		if(!validator.validateAmount(amount))
	{
			try
			{
				throw new BankAccountException("Invalid amount"
						+ "(should be in decimal)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(toacc))
		{
			try
			{
				throw new BankAccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(fromacc))
	{
		try
			{
				throw new BankAccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		return dao.fundTransfer(amount, fromacc,toacc);
	}


//	
//	@Override
//	public List<String> printTransactions(BankAccount ba) throws BankAccountException 
//	{
//		if(!validator.validateAccNo(ba.getAcc_no()))
//		{
//			try
//			{
//				throw new BankAccountException("Invalid Account Number"
//						+ "(should be of 6 digits, numbers only)");
//			}
//			catch(BankAccountException ex)
//			{
//				throw ex;
//			}
//		}
//		return dao.printTransactions(ba);
//	}
//
//	
	
	@Override
	public double showBalance(int accno) throws BankAccountException, IOException, SQLException 
	{
		if(!validator.validateAccNo(accno))
		{
			try
			{
				throw new BankAccountException("Invalid Account Number"
						+ "(Account number should be of 6 digits, numbers only)");
			}
			catch(BankAccountException ex)
			{
				throw ex;
			}
		}
		return dao.showBalance(accno);
	}

	
	
//	@Override
//	public BankAccount getAccount(int accno) throws BankAccountException, IOException 
//	{
//		if(!validator.validateAccNo(accno))
//		{
//			try
//			{
//				throw new BankAccountException("Invalid Account Number"
//						+ "(should be of 6 digits, numbers only)");
//			}
//			catch(BankAccountException ex)
//			{
//				throw ex;
//			}
//		}
//		
//		return dao.getAccount(accno);
//	}



//	@Override
//	public int lastAccount() throws BankAccountException, SQLException, IOException {
//		return dao.lastAccount();
//	}



	@Override
	public void printTransactions(int accno) throws BankAccountException, SQLException, IOException {
		// TODO Auto-generated method stub
		dao.printTransactions(accno);
	}


	@Override
	public boolean checkAccno(int accno) throws BankAccountException, SQLException, IOException {
		// TODO Auto-generated method stub
		return dao.checkAccno(accno);
	}



	


	
}
