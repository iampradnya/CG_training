package com.cg.ams.dto;
//importing packages

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class BankAccount 
{
	@Id
	private  int acc_no;//variable declaration
	private String name;
	private String phone_no;
	private String address;
	private double balance;
//	
//	private List<String> transactions;
//	
//	public BankAccount()
//	{
//		
//		transactions=new ArrayList<String>();
//	}
	//getter and setter methods
	public  int getAcc_no() {
		return acc_no;
	}
	public  void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public String get_name() {
		return name;
	}
	public void set_name(String name) {
		this.name = name;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
//	public List<String> getTransactions() {
//		return transactions;
//	}
//	public void setTransactions(String transaction) {
//		this.transactions.add(transaction);
//	}
//	
	//parameterized constructor
	public BankAccount(int acc_no,String name, String phone_no, String address, double balance, List<String> transactions) {
		super();
		this.acc_no=acc_no;
		this.name = name;
		this.phone_no = phone_no;
		this.address = address;
		this.balance = balance;
		//this.transactions = transactions;
	}

	public BankAccount() {
		
	}
	public String toString()
	{
		return "\nAccount No.="+this.getAcc_no()+"\nName="+this.get_name()+
			"\nPhone No.="+this.getPhone_no()+"\nAddress="+this.getAddress()
				+"\nBalance="+this.getBalance();
				//+
//				"\nNo. of Transactions done="+this.getTransactions().size()
	}

	public String getTransactiontype() {
		
		return null;
	}
	public void setAmount(double new_bal) {
		// TODO Auto-generated method stub
		
	}
	public Double getAmount() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
