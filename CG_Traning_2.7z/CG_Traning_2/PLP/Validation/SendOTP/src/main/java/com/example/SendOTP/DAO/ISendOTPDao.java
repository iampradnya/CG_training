package com.example.SendOTP.DAO;

public interface ISendOTPDao {
	public int sendOtp(String mobileNumber);
}
