package com.example.SendOTP.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SendOTP.DAO.ISendOTPDao;

import javax.transaction.Transactional;

@Service
@Transactional
public class SendOTPServiceImpl implements ISendOTPService{

	@Autowired
	ISendOTPDao dao;
	@Override
	public int sendOtp(String mobileNumber) {
		
		return dao.sendOtp(mobileNumber);
	}

}
