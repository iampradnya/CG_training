package com.example.SendOTP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SendOtpApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(SendOtpApplication.class, args);
		System.out.println("Welcome");
	}

}
