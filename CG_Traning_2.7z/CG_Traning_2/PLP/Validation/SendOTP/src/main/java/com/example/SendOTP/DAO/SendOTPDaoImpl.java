package com.example.SendOTP.DAO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;



import org.springframework.stereotype.Repository;

@Repository
public class SendOTPDaoImpl implements ISendOTPDao{

	@Override
	public int sendOtp(String mobileNumber) {
		int otp = (int)(Math.random() * 10000);			//generated values are like :20,200,2000.
		String verification_otp = Integer.toString(otp);
		sendSms(mobileNumber,verification_otp);
		return otp;
	}

	public boolean sendSms(String mobiles, String message) {
		{

			String authkey ="289404AuOtWobl5d52773e";


			//Sender ID,While using route4 sender id should be 6 characters long.


			String senderId="THANOS";


			//define route

			String route="4";



			//Prepare Url

			URLConnection 
			myURLConnection=null;

			URL myURL=null;

			BufferedReader 
			reader=null;



			//encoding message

			String encoded_message=URLEncoder.encode(message);



			//Send SMS API

			String mainUrl="http://api.msg91.com/api/sendhttp.php?";



			//Prepare parameter string

			StringBuilder 
			sbPostData= new 
			StringBuilder(mainUrl);

			sbPostData.append("authkey="+authkey);

			sbPostData.append("&mobiles="+mobiles);

			sbPostData.append("&message="+encoded_message);

			sbPostData.append("&route="+route);

			sbPostData.append("&sender="+senderId);



			//final string

			mainUrl = sbPostData.toString();

			try

			{

				//prepare connection

				myURL =new URL(mainUrl);

				myURLConnection = myURL.openConnection();

				myURLConnection.connect();

				reader= new BufferedReader(new InputStreamReader(myURLConnection.getInputStream()));

				//reading response

				String response;

				while ((response =reader.readLine()) !=null)

					//print response

					System.out.println(response);



				//finally close connection

				reader.close();

				return true;

			}

			catch (IOException e)

			{

				e.printStackTrace();

				return false;

			}



		}

		
	}
}
