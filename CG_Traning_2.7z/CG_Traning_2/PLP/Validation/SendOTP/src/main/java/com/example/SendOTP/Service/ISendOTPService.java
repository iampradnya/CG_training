package com.example.SendOTP.Service;

public interface ISendOTPService {
	public int sendOtp(String mobileNumber);
}
