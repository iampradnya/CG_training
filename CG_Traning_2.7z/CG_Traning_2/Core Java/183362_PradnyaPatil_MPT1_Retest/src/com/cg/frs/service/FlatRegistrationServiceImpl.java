package com.cg.frs.service;

import java.util.ArrayList;
import java.util.Map;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatException;
import com.cg.frs.validator.DataValidator;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService{

	IFlatRegistrationDAO dao;
	DataValidator validator;
	
	public FlatRegistrationServiceImpl() {
		dao=new FlatRegistrationDAOImpl();
		validator=new DataValidator();
		
	}

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatException {
		if(!validator.validateFlatType(flat.getFlatType())) {
			throw new FlatException("Flat Type should be either 1 or 2");
		}else {
			int registrationId =(int) (Math.random()*10000);
			flat.setRegistrationId(registrationId);;
			return dao.registerFlat(flat);
		}
		
		
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatException {
		// TODO Auto-generated method stub
		return dao.getAllOwnerIds();
	}

	@Override
	public Map<Integer, FlatRegistrationDTO> getRegistrationDetails() throws FlatException {
		// TODO Auto-generated method stub
		return dao.getRegistrationDetails();
	}

}
