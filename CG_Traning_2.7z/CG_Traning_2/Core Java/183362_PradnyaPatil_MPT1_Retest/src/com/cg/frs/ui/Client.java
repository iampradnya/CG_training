package com.cg.frs.ui;
//importing the packages
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Client {
	public static void main(String[] args) throws FlatException {
		do {
			List<Integer> ownerList=new ArrayList<>();
			IFlatRegistrationService service=new FlatRegistrationServiceImpl();
			Scanner scanner=new Scanner(System.in);
			System.out.println("1)Register Flat");
			System.out.println("2)Display Flat Registration Details");
			System.out.println("3)Exit");
			int option=0;
			try {
			option=scanner.nextInt();
			}catch(InputMismatchException e)
			{
				System.out.println("Enter an Inetger Value");
			}
			switch(option) {
			case 1:
				System.out.println("Existing Owner IDS Are:");
				ownerList=service.getAllOwnerIds();
				System.out.println(ownerList);
				FlatRegistrationDTO flatRegister=new FlatRegistrationDTO();
				flatRegister=getAllRegistrationDetails();
				try {
					
					flatRegister=service.registerFlat(flatRegister);
					System.out.println("Flat Succesfully Registered");
					System.out.println("Registration ID:"  +flatRegister.getRegistrationId());
					System.out.println("Flat Type:" +flatRegister.getFlatType());
					System.out.println("Flat Area:" +flatRegister.getSquareFeet());
					System.out.println("Rent Amount:" +flatRegister.getRentAmount());
					System.out.println("Deposit Amount:" +flatRegister.getDepositeAmount());
				}catch(FlatException e) 
				{
					System.out.println(e.getMessage());
				}
				
				
				
				break;
			case 2: 
				
				Map<Integer,FlatRegistrationDTO> flatDetails=new HashMap<>();
				flatDetails=service.getRegistrationDetails();
				if(flatDetails.isEmpty()) {
					System.out.println("No Registration Done");
				}else {
					System.out.println(flatDetails);
				}
				break;
			case 3:
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Please Enter Valid Option");
				break;
			}//switch ends
			
			
		}//do ends
		while(true);//while ends
	}
	
	public static FlatRegistrationDTO getAllRegistrationDetails() {
		FlatRegistrationDTO flatregistration=new FlatRegistrationDTO();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Please enter owner ID from above list:");
		
		try {
			int ownerId=scanner.nextInt();
			flatregistration.setFlatOwnerId(ownerId);
		} catch (InputMismatchException e) {
			
		System.out.println("Please enter an integer value");
		}
		
		System.out.println("Enter flat type:");
		try {
			int flatType=scanner.nextInt();
			flatregistration.setFlatType(flatType);
		} catch (InputMismatchException e1) {
			// TODO Auto-generated catch block
			System.out.println("Please enter an integer value");
		}
		System.out.println("Enter an area in square.feet");
		try {
			int squarefeet=scanner.nextInt();
			flatregistration.setSquareFeet(squarefeet);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter  an Integer value");
		}
		System.out.println("Enter an Desired Rent amount");
		
		try {
			int rentAmount=scanner.nextInt();
			flatregistration.setRentAmount(rentAmount);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter  an Integer value");
		}
		
		System.out.println("Enter an Deposit amount");
		
		try {
			int depositAmount=scanner.nextInt();
			flatregistration.setDepositeAmount(depositAmount);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter  an Integer value");
		}
		return flatregistration;
		
	}

}
