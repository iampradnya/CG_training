package com.cg.frs.dto;

public class FlatOwner {
	// defining properties
	private int ownerId;//variable declaration
	private String ownerName;
	private String ownermobileNo;
	//getter and setter methods
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getOwnermobileNo() {
		return ownermobileNo;
	}
	public void setOwnermobileNo(String ownermobileNo) {
		this.ownermobileNo = ownermobileNo;
	}
	@Override
	public String toString() {
		return "FlatOwner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownermobileNo=" + ownermobileNo + "]";
	}
	//parameterized constructor
	public FlatOwner(int ownerId, String ownerName, String ownermobileNo) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.ownermobileNo = ownermobileNo;
	}
	public FlatOwner() {
		super();
	}
	
	
	}
	
	


