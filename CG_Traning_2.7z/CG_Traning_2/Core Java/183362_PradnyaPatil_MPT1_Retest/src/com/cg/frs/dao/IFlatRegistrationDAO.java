package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatException;

public interface IFlatRegistrationDAO {
	//methods declaration
	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatException;
	ArrayList<Integer> getAllOwnerIds() throws FlatException;
	Map<Integer,FlatRegistrationDTO> getRegistrationDetails() throws FlatException;

}
