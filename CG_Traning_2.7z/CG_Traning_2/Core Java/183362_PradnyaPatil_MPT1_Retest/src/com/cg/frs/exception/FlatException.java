package com.cg.frs.exception;

public class FlatException extends Exception {
	
	public FlatException(){
		super("Some Error Occured ");
		}
	public FlatException(String str) {
		super(str);
	}

}
