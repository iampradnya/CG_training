package com.cg.frs.dto;

public class FlatRegistrationDTO {
	//defining properties
	private int registrationId;//variable declaration
	private int flatType;
	private int squareFeet;
	private int rentAmount;
	private int depositeAmount;
	private int flatOwnerId;
	//getter and setter methods
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public int getSquareFeet() {
		return squareFeet;
	}
	public void setSquareFeet(int squareFeet) {
		this.squareFeet = squareFeet;
	}
	public int getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(int rentAmount) {
		this.rentAmount = rentAmount;
	}
	public int getDepositeAmount() {
		return depositeAmount;
	}
	public void setDepositeAmount(int depositeAmount) {
		this.depositeAmount = depositeAmount;
	}
	public int getFlatOwnerId() {
		return flatOwnerId;
	}
	public void setFlatOwnerId(int flatOwnerId) {
		this.flatOwnerId = flatOwnerId;
	}
	
	public FlatRegistrationDTO(int registrationId, int flatType, int squareFeet, int rentAmount, int depositeAmount,
			int flatOwnerId) {
		super();
		this.registrationId = registrationId;
		this.flatType = flatType;
		this.squareFeet = squareFeet;
		this.rentAmount = rentAmount;
		this.depositeAmount = depositeAmount;
		this.flatOwnerId = flatOwnerId;
	}
	public FlatRegistrationDTO() {
		super();
	}
	@Override
	public String toString() {
		return "RegistrationDetails [registrationId=" + registrationId + ", flatType=" + flatType + ", squareFeet="
				+ squareFeet + ", rentAmount=" + rentAmount + ", depositeAmount=" + depositeAmount + ", flatOwnerId="
				+ flatOwnerId + "]";
	}

	
	

}
