import java.util.*;
public class Power {
	int i=0;
	double res=0;
	boolean checkPower(int n) {
		if(n%2==0)
		{
			while(n>res)
			{
				res=Math.pow(2, i);
				i++;
			}
			if(n==res)
			{
				return true;
				
			}
			else
			{
				return false;
			}
		}
		else {
			return false;
		}
	}
	public static void main(String args[]) {
		Power e=new Power();
		System.out.println(e.checkPower(30));
	}
}
