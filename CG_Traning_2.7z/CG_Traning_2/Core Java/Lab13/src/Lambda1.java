import java.util.Scanner;
import java.util.concurrent.SynchronousQueue;

public class Lambda1 {

	public static void main (String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no:");
		Powerdemo pd=(double x,double y)->Math.pow(x, y);
		double x=sc.nextDouble();
		double y=sc.nextDouble();
		double res=pd.calculatepower(x, y);
		System.out.println(res);
		sc.close();
	}
			
}
