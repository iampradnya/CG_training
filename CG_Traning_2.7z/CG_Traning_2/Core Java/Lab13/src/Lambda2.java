import java.util.Scanner;
import java.util.function.Consumer;

public class Lambda2 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String str=sc.nextLine();
		CharacterSpace cp=(String s1)->{
			
			String StrSpace="";
			for(int i=0;i<str.length();i++) {
				StrSpace+=str.charAt(i);
				StrSpace+=" ";
			}
			return StrSpace;
			
		};
		
		String CharacterSpace=cp.character(str);
		Consumer<String> con=(string)-> System.out.println("String with space:" +string);
		con.accept(CharacterSpace);
		sc.close();
	}
}
