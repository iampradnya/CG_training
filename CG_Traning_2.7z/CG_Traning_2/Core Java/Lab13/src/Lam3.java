
public interface Lam3 {
	boolean UsrPass(String x,String y);
}
