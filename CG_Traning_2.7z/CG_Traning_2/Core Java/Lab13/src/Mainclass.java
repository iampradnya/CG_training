import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Mainclass {
  
	private String empID;
	private String name;
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public static void main(String args[]) {
		Mainclass m=new Mainclass();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter emp ID:");
		String empID=sc.nextLine();
		System.out.println("Enter emp name");
		String name=sc.nextLine();
		
		Consumer<String> con1=m::setName;
		 Consumer <String> con2=m::setEmpID;
		
		con1.accept(name);
		con2.accept(empID);
		 
		Supplier <String> sup1=m::getName;
		 Supplier <String> sup2=m::getEmpID;
		
		System.out.println(sup1.get());
		System.out.println(sup2.get());
	}
}
