
public interface Powerdemo {
	double calculatepower(double x,double y);

}
