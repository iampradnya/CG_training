
public interface CharacterSpace {
	
	String character(String str);

}
