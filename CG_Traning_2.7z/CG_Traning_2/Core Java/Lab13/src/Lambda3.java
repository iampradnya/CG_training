import java.util.Scanner;
import java.util.function.Consumer;

public class Lambda3 {
	public static void main (String [] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username");
		String str1=sc.nextLine();
		System.out.println("Enter Password");
		String str2=sc.nextLine();
		
		Lam3 l=(String usrname, String passwd)-> 
		{
			if(usrname.equals("Admin") && passwd.equals("Admin123")) 
			{
				return true;
			}
			else {
				return false;
			}
		};	
	
	boolean res=l.UsrPass( str1,str2);
	/* Consumer <Boolean> con=(num)-> {
		if(num) {
			System.out.println("valid");
		}
	
		else {
			System.out.println("Invalid");
	
		}
	};
	con.accept(res); */
	
	System.out.println(res);
	sc.close();
}
	

}
