/*package com.cg.productmgmt.testcase;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

import org.junit.jupiter.api.Test;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.ProductService;

class ProductTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}
	
	ProductDAO daoobj= new ProductDAO();
	ProductService service = new ProductService();
	
	@Test
	public void testMapalues() {
		try {
			Map<String, Integer> p1 = daoobj.getProductDetails();
			assertNotNull(p1);
		} catch (ProductException e) {
		}
	}
	
	@Test
	public void testCategory() {
		String Category="vehicles";
		int hike = 10;
		assertThrows(ProductException.class, ()->service.updateProducts(Category, hike));
	}
	
	
	@Test
	public void testhike() {
		String Category="electronics";
		int hike = 0;
		ProductDAO daoobj= new ProductDAO();
		assertThrows(ProductException.class, ()->daoobj.updateProducts(Category, hike));
		}

}
*/