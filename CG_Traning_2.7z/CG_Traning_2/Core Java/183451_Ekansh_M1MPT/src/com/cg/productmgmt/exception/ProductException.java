package com.cg.productmgmt.exception;

public class ProductException extends Exception{
	
	public ProductException()
	{
		super("Some error occured");
	}
	
	public ProductException(String str)
	{
		super(str);
	}

}
