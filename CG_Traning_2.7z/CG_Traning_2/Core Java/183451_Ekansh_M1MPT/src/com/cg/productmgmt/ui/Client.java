package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.ProductService;

public class Client {
	public static int updateProduct() throws ProductException
	{
		ProductService productService = new ProductService();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Product Category ");
		String category = sc.next();
		System.out.println("Enter hike price ");
		int hike = sc.nextInt();
		return productService.updateProducts(category, hike);
		
	}
	
	public static void getDetails()throws ProductException
	{
		ProductService productService = new ProductService();
		
		Map<String, Integer> productdetails = productService.getProductDetails();
		for(Map.Entry<String, Integer> entry : productdetails.entrySet())
		{
			System.out.println("Product  " + entry.getKey() + "  price  " + entry.getValue());
		}
	}

	public static void main(String[] args)throws ProductException {
		Scanner sc = new Scanner(System.in);
		int option;
		do
		{
			System.out.println("1---Update Product Price");
			System.out.println("2---Display Product List");
			System.out.println("3---Exit");
			System.out.println(".................................................");
			System.out.println("Enter any option");
			option = sc.nextInt();
			switch (option) {
			case 1:
				try
				{
					updateProduct();
				}catch(ProductException p)
				{
					System.out.println(p.getMessage());
				}catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
			
			case 2:
				try
				{
					getDetails();
				}catch(ProductException p)
				{
					System.out.println(p.getMessage());
				}catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
				
			case 3:
				System.out.println("Thankyou !!!");
				sc.close();
				System.exit(0);
				break;

			default:
				System.out.println("Please enter an proper option");
				break;
			}
		}while(true);

	}

}
