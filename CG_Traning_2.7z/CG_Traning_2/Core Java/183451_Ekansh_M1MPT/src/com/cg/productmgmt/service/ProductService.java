package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService{
	ProductDAO daoobject;
	public ProductService() {
		daoobject = new ProductDAO();
		
	}
	
	@Override
	public int updateProducts(String category, int hike)throws ProductException {
		if(hike<0)
		{
			throw new ProductException("Hike should be greater");
		}
		
		return daoobject.updateProducts(category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails()throws ProductException {
		// TODO Auto-generated method stub
		return daoobject.getProductDetails();
	}

}
