
package lab3;
import java.io.IOException;
import java.util.Arrays;

public class Ex2StringArray{
	public void manipulatestring(String array[]) {
		int n;
		if(array.length%2==0)
		{
			n=array.length/2;
			
		}
		else
		{
			n=(array.length/2)+1;
		}
		for(int i=0;i<n;i++)
		{
			System.out.println(array[i].toUpperCase());
			
		}
		for(int j=n;j<array.length;j++)
		{
			System.out.println(array[j]);
		}
	}
	public static void main(String args[])
	{
		//String array[]= {"ABC","DEF","PQR","LMN","XYZ","ASR","SRK"};
		try {
			String array[]= {"pradnya","prasad","sarika","rekha","ganesh","rifat","nandu"};
			//int i = 0;
			//array[i]=array[i].toLowerCase();
			Ex2StringArray sa=new Ex2StringArray();
			Arrays.sort(array);
			sa.manipulatestring(array);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

