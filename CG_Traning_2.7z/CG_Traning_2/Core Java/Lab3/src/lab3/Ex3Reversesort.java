package lab3;


import java.util.Arrays;

public class Ex3Reversesort {
	
	int[] Array(int n[])
	{
		int b[]=n;
		int len=b.length;
		for(int i=0;i<len;i++)
		{
			String c=Integer.toString(b[i]);
			StringBuffer s=new StringBuffer(c);
			s.reverse();
			String d=s.toString();
			b[i]=Integer.parseInt(d);
			}
		Arrays.sort(b);
		return b;	
	}
		public static void main(String args[]) {
			try {
				int[] n=new int[] {13,45,74,69,58};
				Ex3Reversesort rs=new Ex3Reversesort();
				int res[]=rs.Array(n);
				System.out.println(Arrays.toString(res));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	

