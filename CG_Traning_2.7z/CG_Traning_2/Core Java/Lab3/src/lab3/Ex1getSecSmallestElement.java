package lab3;
	import java.lang.reflect.Array;
	import java.util.Arrays;

	public class Ex1getSecSmallestElement {
	public int getSecondSmallest(int arr[])
	{
	Arrays.sort(arr);;
	int element=arr[1];
	return element;
	}
	public static void main(String[] args) {
	try {
		int arr[]= {89,34,233,45,6,784,879};
		Ex1getSecSmallestElement ss= new Ex1getSecSmallestElement();
		int res= ss.getSecondSmallest(arr);
		System.out.println(res);
	} catch (NumberFormatException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	}

