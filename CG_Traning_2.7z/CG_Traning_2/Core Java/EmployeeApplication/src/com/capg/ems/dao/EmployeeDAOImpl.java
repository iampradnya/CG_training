package com.capg.ems.dao;

import com.capg.ems.dto.Employee;
import com.capg.ems.exception.EmployeeException;

import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
public class EmployeeDAOImpl implements EmployeeDAO
{
	private static Map<String,Employee> employees=new HashMap<>();
	
	@Override
	public Employee AddEmployee(Employee emp) {
		employees.put(emp.getEmpID(),emp);
		return emp;
	}
	
	@Override
	public List<Employee> getEmployees(){
		Collection<Employee> list=employees.values();
		List<Employee> empList=new ArrayList<>(list);
		return empList;
	}
	
	
	@Override
	public Employee deleteEmployee(String empid) throws EmployeeException {
		// TODO Auto-generated method stub
		Employee emp=employees.remove(empid);
		if(emp == null)
			throw new EmployeeException("Exception not found");
		else return emp ;
	}

	@Override
	public Employee getEmployee(String empid) throws EmployeeException {
		// TODO Auto-generated method stub
		Employee emp=employees.get(empid);
		if(emp==null)
		
			throw new EmployeeException("Employee not found");
		
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		employees.replace(emp.getEmpID(), emp);
		if(emp.getEmpID().equals(null))
		{
			throw new EmployeeException("Employee not found");
		}
		return emp;
	}

	
	
}
