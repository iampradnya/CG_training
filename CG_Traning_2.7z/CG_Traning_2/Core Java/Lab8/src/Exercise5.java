import java.util.*;

public class Exercise5 {

	public static void main(String[] args) {
		System.out.println("Enter a string");
		Scanner sc= new Scanner(System.in);
		 String s = sc.nextLine();  
         
	        if (isAlphabaticOrder(s))  
	           System.out.println("Entered string "+s+" is a postive string");  
	        else
	            System.out.println("Entered string "+s+" is a negative string");  
	       
	        sc.close();
	    }

	private static boolean isAlphabaticOrder(String s) {
		// TODO Auto-generated method stub
		 try {
			int n = s.length();  
			     
			    char c[] = new char [n];  
			   
			    for (int i = 0; i < n; i++) {  
			        c[i] = s.charAt(i);  
			    }  
			    
			    // sort the character array  
			    Arrays.sort(c);  
			    
			    // check if the character array  
			    // is equal to the string or not  
			    for (int i = 0; i < n; i++)  
			        if (c[i] != s.charAt(i))   
			            return false;  
			            
			    return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;      
	    }   
	
	
	

}
