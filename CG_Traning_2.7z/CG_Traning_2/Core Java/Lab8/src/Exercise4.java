import java.io.File;
import java.util.Scanner;

public class Exercise4{
	public static String check(boolean n) {
		String d="";
		if(n==true)
		{
			d="YES";
			return d;
		
		}else
		{
			d="NO";
			return d;
		}
	}
	private static String getFileExtension(File file) {
		String filename=file.getName();
		return filename.substring(filename.lastIndexOf(".")+1);
	}
	public static void main(String [] args) {
		try {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter file name");
			String str=sc.next();
			File f=new File(str);
			System.out.println("Exist:"  +check(f.exists()));
			System.out.println("Readable:" +check(f.canRead()));
			System.out.println("Writable:" +check(f.canWrite()));
			System.out.println("Size:" +f.length());
			System.out.println("File Type:" +getFileExtension(f));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}