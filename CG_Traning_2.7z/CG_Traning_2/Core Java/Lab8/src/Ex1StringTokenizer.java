
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Ex1StringTokenizer {

	public static void main(String[] args)  {
		
		
		int sum=0;
		int n=0;
		String line="";
		try {
			BufferedReader reader=new BufferedReader(new FileReader("C:\\Users\\ppati100\\Desktop\\demo.txt"));
			line=reader.readLine();
			StringTokenizer st=new StringTokenizer(line);

			while(st.hasMoreTokens())
			{
				String str=st.nextToken();
				n=Integer.parseInt(str);
				System.out.println(n);
				sum=sum+n;
			}
			System.out.println("sum of no in file is " +sum);
			
		}
		catch(IOException io)
		{
			System.out.println("File not found");
		}
		
			
			
	}

}

