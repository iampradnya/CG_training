import java.time.*;
import java.util.Scanner;
public class Exercise6 {
	int d,m,y;
	Scanner sc=new Scanner(System.in);
	
	public void getDate() {
		
		System.out.println("Enter date(dd)");
		d=sc.nextInt();
		System.out.println("Enter Month(mm):");
		m=sc.nextInt();
		System.out.println("Enter year(yyyy):");
		y=sc.nextInt();
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Exercise6 ex=new Exercise6();
			ex.getDate();
			LocalDate id=LocalDate.of(ex.y, ex.m, ex.d);
			LocalDate d=LocalDate.now();
			System.out.println(id);
			Period gap=Period.between(id, d);
			System.out.println("Difference between" +id+ " & " +d+"is:\nIn days:" +gap.getDays()+ "\nIn months:"
					+gap.getMonths()+"\nIn years:" +gap.getYears());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
