import java.io.*;

public class Ex2FileOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader reader;
		int x=1;
		try {
			reader=new BufferedReader(new FileReader("C:\\Users\\ppati100\\Documents\\TextFile\\Text.txt"));
			String line=reader.readLine();
			while(line!=null) {
				System.out.println(x+ "");
				System.out.println(line);
				//read next line;
				line=reader.readLine();
				x++;
			}
			reader.close();
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
