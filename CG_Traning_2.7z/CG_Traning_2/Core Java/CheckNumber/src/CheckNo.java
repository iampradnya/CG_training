
public class CheckNo {
	public boolean CheckNo(int number) {
		boolean flag=true;
		int currentDigit=number%10;
		number=number/10;
		while(number>0) 
			{
			
			if(currentDigit<number%10) {
				flag=false;
				break;
			}
			currentDigit=number%10;
			number=number/10;
		}
		if(flag) {
			return true;
		}
		else
		return false;
		
	}
	public static void main(String [] args) {
		CheckNo obj=new CheckNo();
		
			System.out.println(obj.CheckNo(12234));
	}
}
	