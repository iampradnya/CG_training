
import java.util.Scanner;

public class Ex3PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		int number,count;
		System.out.println("Enter an integer value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		for(number=1;number<=n;number++)
		{
			count=0;
			for(int j=2;j<=number/2;j++)
			{
				if(number%j==0)
				{
					count++;
					break;
				}
			}
				if(count ==0 && number!=1)
				{
					System.out.println(number +"");
				}
				
			}
		sc.close();
		}
	catch(Exception e)
	{
		e.getMessage();
	}
}

}
