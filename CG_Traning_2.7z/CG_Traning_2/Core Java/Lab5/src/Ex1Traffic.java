import java.util.Scanner;

public class Ex1Traffic {

	public static void main(String[] args) throws EmployeeException {
		
		try{
			do {
				Scanner sc = new Scanner(System.in);
			System.out.println("Select one of the three lights");
			System.out.println("1)red 2)Yellow 3)Green 4)Exit");
			
			int opt = sc.nextInt();
			boolean validate=Ex1Traffic.validateInput(opt);
			if(validate)
			{
			switch (opt) {
			case 1:
				System.out.println("STOP");
				break;
			case 2:
				System.out.println("READY");
				break;
			case 3:
				System.out.println("GO");
				break;
			case 4:
				System.exit(0);
			default:
				throw new EmployeeException("please enter the correct option");
				
			}}
			else
			{
				throw new EmployeeException("enter correct option");
			}

		} while (true);
	}catch(EmployeeException e)
	{
		e.getMessage();
	}
	}

	private static boolean validateInput(int opt) {
		// TODO Auto-generated method stub
		
		if(opt==1 || opt==2 ||opt==3|| opt==4)
		{	
		return true;
		}
		else
		{
		return false;}
	}
	
	
}
