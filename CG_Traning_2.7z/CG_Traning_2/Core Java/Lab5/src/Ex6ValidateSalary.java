import java.util.Scanner;

public class Ex6ValidateSalary {
	public static void main(String[] args) throws EmployeeException
	{
		try {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your salary");
		double salary=sc.nextDouble();
		sc.close();
		if(salary<0)
		{
			throw new EmployeeException("salary cannot be negative");
		}
		else if(salary<3000)
		{

			throw new EmployeeException("salary should be greater than 3000");
		}
		else
		{
			System.out.println("SALARY: "+"$"+ salary);	
		}
		}catch(EmployeeException e)
		{
			e.getMessage();
		}
	}
}
