import java.util.Scanner;

public class Ex4ValidateName {
	
	

	public static void main(String[] args) throws EmployeeException 
	{
		try {
			Scanner sc= new Scanner(System.in);
			System.out.println("enter your firstname");
			String firstName=sc.next();
			System.out.println("enter your lastname");
			String lastName=sc.next();
			sc.close();
			
			if(firstName.isEmpty()|| lastName.isEmpty())
			{
				throw new EmployeeException("Name cannot be negative");
			}
			else
			{
				System.out.println("NAME: "+ firstName+""+lastName);	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
