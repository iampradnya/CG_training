package getSecondSmallest;

import java.util.Arrays;




public class getSecSmallest {
	
	public int getSecondSmallest(int arr[]) {
		Arrays.sort(arr);
		int element=arr[1];
		return element;
	}
	
	public static void main(String[] args) {
	

	int array[]= {25,45,65,23,41,10,52};
	getSecSmallest se=new getSecSmallest();
	int res=se.getSecondSmallest(array);
	System.out.println(res);
	
	
}
}