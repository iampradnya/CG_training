package com.cg.emp.service;

import java.util.List;

import com.cg.emp.dao.EmpDao;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmpService implements IEmpService {

EmpDao dao;
DataValidator validator;


	public EmpService() {
	dao=new EmpDao();
	validator=new DataValidator();
}

	@Override
	public Employee addEmployee(Employee emp) throws EmployeeException {
		
		if(!validator.validateName(emp.getName())) {
			throw new EmployeeException("Name is not valid");
			}
		if(!validator.validateLocation(emp.getLocation())) {
			throw new EmployeeException("Invalid location");
		}
		if(!validator.validateMobileNo(emp.getMobileNo())) {
			throw new EmployeeException("Invalid Mobile number");
		}
		if(!validator.validateEmpID(emp.getEmpID())) {
			throw new EmployeeException("Invalid Employee id");
		}
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
		
		
	}

	@Override
	public List<Employee> getEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployee();
	}

	@Override
	public Employee deleteEmployee(String empid) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(empid);
	}

	@Override
	public Employee getEmployee(String empid) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployee(empid);
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.updateEmployee(emp);
	}

}
