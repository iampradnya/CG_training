package com.cg.emp.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;


public class EmpDao implements IEmpDao {
	private static Map<String,Employee> employees=new HashMap<>();

	@Override
	public Employee addEmployee(Employee emp) throws EmployeeException {
		employees.put(emp.getEmpID(), emp);
		return emp;
	}

	@Override
	public List<Employee> getEmployee() throws EmployeeException {
		Collection<Employee> list=employees.values();
		List<Employee> emplist=new ArrayList<>(list);
		
		return emplist;
	}

	@Override
	public Employee deleteEmployee(String empid) throws EmployeeException {
		Employee emp=employees.remove(empid);
		if(emp==null) {
			throw new EmployeeException ("Employee Id not found");
			
		}
		return emp;
	}

	@Override
	public Employee getEmployee(String empid) throws EmployeeException {
		Employee emp=employees.get(empid);
				if(emp==null) {
					throw new EmployeeException("Employee not found");
				}
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		employees.replace(emp.getEmpID(), emp);
		if(emp.getEmpID().equals(null)) {
			throw new EmployeeException("Employee not found");
		}
		return emp;
	}
	
	

}
