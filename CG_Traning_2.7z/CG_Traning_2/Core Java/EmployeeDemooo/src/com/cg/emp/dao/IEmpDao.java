package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;



public interface IEmpDao {
	public Employee addEmployee(Employee emp) throws EmployeeException;
	public List<Employee> getEmployee() throws EmployeeException;
	public Employee deleteEmployee(String empid) throws EmployeeException;
	public Employee getEmployee(String empid) throws EmployeeException;
	public Employee updateEmployee(Employee emp) throws EmployeeException;
	

}
