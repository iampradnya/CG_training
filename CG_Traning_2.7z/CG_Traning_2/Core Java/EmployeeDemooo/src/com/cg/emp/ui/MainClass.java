package com.cg.emp.ui;

import java.util.List;
import java.util.Scanner;


import com.cg.emp.dto.Employee;
import com.cg.emp.service.EmpService;
import com.cg.emp.service.IEmpService;

public class MainClass {
	public static Employee acceptEmployeeDetails() {
		Employee emp=new Employee();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Employee ID");
		String id=sc.next();
		emp.setEmpID(id);
		System.out.println("Enter Name");
		String name=sc.next();
		emp.setName(name);
		System.out.println("Enter Salary");
		double sal=sc.nextDouble();
		emp.setSalary(sal);
		System.out.println("Enter Mobile NO");
		String mob=sc.next();
		emp.setMobileNo(mob);
		System.out.println("Enter Dept Code");
		int dno=sc.nextInt();
		emp.setDeptCode(dno);
		System.out.println("Enter location");
		String loc=sc.next();
		emp.setLocation(loc);
		
		return emp;
		
	}
	public static void displayEmployees(List<Employee> empList)
	{
		for(Employee e:empList) {
			System.out.println(e.getEmpID()+"");
			System.out.println(e.getName()+"");
			System.out.println(e.getMobileNo()+"");
			System.out.println(e.getSalary()+"");
			System.out.println(e.getLocation()+"");
			System.out.println(e.getDeptCode()+"");
			
		}
}
public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		IEmpService service=new EmpService();
		do {
			
		
		System.out.println("1.Add Employee");
		System.out.println("2.Display Employee List");
		System.out.println("3.Delete Employee");
		System.out.println("4.Update Employee");
		System.out.println("5.Display Employee");
		System.out.println("6.Exit");
		System.out.println("Enter Option:");
		Scanner sc=new Scanner(System.in);
		int option=sc.nextInt();
		switch(option) {
		case 1:
			Employee emp=acceptEmployeeDetails();
			try {
				emp=service.addEmployee(emp);
				System.out.println("employee added.....");
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			
			break;
		case 2: 
			try {
				
			
			List<Employee> list=service.getEmployee();
			displayEmployees(list);
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			break;
			
		case 3:
			System.out.println("Enter employee id");
			String id=sc.next();
			try {
			emp=service.deleteEmployee(id);
			System.out.println("Employee deleted.....");}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			break;
			
		case 4:
			Employee emp1 =acceptEmployeeDetails();
			try {
				emp1=service.updateEmployee(emp1);
				System.out.println("Employee updated");
			}
			catch(Exception e ) {
				System.out.println(e.getMessage());
			}
			break;
			
			
		case 5:
			System.out.println("Enter Employee id");
			id=sc.next();
			try {
				emp1=service.getEmployee(id);
				System.out.println("Employee details:" +emp1);
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			break;
			
		case 6: 
			sc.close();
			System.exit(0);
		} //switch end
		
	} while(true); //do while end
} //main method end
}
