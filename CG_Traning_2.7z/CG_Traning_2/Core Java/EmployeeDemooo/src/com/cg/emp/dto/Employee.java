package com.cg.emp.dto;

public class Employee {
	private String empID;
	private String name;
	private double salary;
	private int deptCode;
	private String location;
	private String mobileNo;
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(int deptCode) {
		this.deptCode = deptCode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", name=" + name + ", salary=" + salary + ", deptCode=" + deptCode
				+ ", location=" + location + ", mobileNo=" + mobileNo + "]";
	}
	public Employee(String empID, String name, double salary, int deptCode, String location, String mobileNo) {
		super();
		this.empID = empID;
		this.name = name;
		this.salary = salary;
		this.deptCode = deptCode;
		this.location = location;
		this.mobileNo = mobileNo;
	}
	public Employee() {
		super();
	}
	
}
