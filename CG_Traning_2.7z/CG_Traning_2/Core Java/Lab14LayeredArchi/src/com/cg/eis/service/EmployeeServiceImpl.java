package com.cg.eis.service;

import java.util.List;

import com.cg.eis.dao.EmployeeDAO;
import com.cg.eis.dao.EmployeeDAOImpl;
import com.cg.eis.service.DataValidator;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO dao;
	
	public EmployeeServiceImpl() {
		dao=new EmployeeDAOImpl();
		
	}

	@Override
	public Employee AddEmployee(Employee emp) throws Exception {
		// TODO Auto-generated method stub
		return dao.AddEmployee(emp);
	}

	@Override
	public List<Employee> getInsuranceScheme() throws Exception {
		// TODO Auto-generated method stub
		return dao.getInsuranceScheme();
	}

	@Override
	public Employee getEmployee(String empid) throws Exception {
		// TODO Auto-generated method stub
		return dao.getEmployee(empid);
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return dao.getEmployees();
	}

	
}