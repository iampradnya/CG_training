package com.cg.eis.pl;


import java.util.List;
import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.bean.Employee;


public class Main {

	public static Employee acceptEmployeeDetails() {
		Employee emp = new Employee();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee ID");
		String id = sc.next();
		emp.setEmpID(id);
		System.out.println("Enter Name");
		String name = sc.next();
		emp.setName(name);
		System.out.println("Enter Salary");
		int sal = sc.nextInt();
		emp.setSalary(sal);
		System.out.println("Enter designation");
		String designation = sc.next();
		emp.setDesignation(designation);
		System.out.println("Enter Insurance scheme");
		String InsuranceSceme = sc.next();
		emp.setInsuranceSceme(id);
		return emp;
	}

	public static void displayEmployees(List<Employee> empList) {
		for (Employee e : empList) {
			System.out.println(e.getEmpID() + "");
			System.out.println(e.getName() + "");
			System.out.println(e.getSalary() + "");
			System.out.println(e.getDesignation() + "");
			System.out.println(e.getInsuranceSceme() + "");

		}
	}

public static void main(String[] args) throws Exception {
		
		EmployeeServiceImpl service=new EmployeeServiceImpl();
		Main m=new Main();
		Scanner sc=new Scanner(System.in);
		do {
			
		
		System.out.println("1.Add Employee");
		System.out.println("2.Display Employee List");
		System.out.println("3.Find the insurance scheme for an employee based on salary and designation.");
		System.out.println("4.Exit");
		System.out.println("Enter Option:");
		Scanner in=new Scanner(System.in);
		int option=sc.nextInt();
		
		switch(option) {
	
		case 1: Employee emp=m.acceptEmployeeDetails();
		emp=service.AddEmployee(emp);
		System.out.println("Employee added.....");
		break;
		
		case 2:
			List <Employee> list=service.getEmployees();
			displayEmployees(list);
			break;
		case 3:
			System.out.println("Enter Employee ID ");
			String empID=sc.next();
			List<Employee> displayemp=(List<Employee>) service.getEmployee(sc.next());
			displayEmployees(displayemp);
			break;
		case 4:
			System.out.println("Good byeeeee!!!!!!!!!!!");
			in.close();
			System.exit(0);
			break;
		}
		}
		while(true);
}
private static Employee acceptEmployee() throws EmployeeException{
	String insuranceScheme="";
	Scanner sc1 = new Scanner(System.in);
	Employee emp1 = new Employee();

	System.out.println("Enter employeeId:");
	String employeeId = sc1.next();
	emp1.setEmpID(employeeId);

	System.out.println("Enter employee name:");
	String employeeName = sc1.next();
	emp1.setName(employeeName);

	System.out.println("Enter eemployee salary ");
	int salary = sc1.nextInt();
	emp1.setSalary(salary);

	System.out.println("Enter employee designation:");
	String designation = sc1.next();
	emp1.setDesignation(designation);

	if (salary > 5000 && salary < 20000 && designation.equalsIgnoreCase("SystemAssociate")) {
		insuranceScheme = "Scheme A";
		emp1.setInsuranceSceme(insuranceScheme);
	} else if (salary >= 20000 && salary < 40000 && designation.equalsIgnoreCase("Programmer")) {
		insuranceScheme = "Scheme B";
		emp1.setInsuranceSceme(insuranceScheme);
	} else if (salary >= 40000 && designation.equalsIgnoreCase("Manager")) {
		insuranceScheme = "Scheme C";
		emp1.setInsuranceSceme(insuranceScheme);
	} 
	else if(salary< 5000 && designation.equalsIgnoreCase("Clerk"))
	{
		insuranceScheme = "No Scheme";
		emp1.setInsuranceSceme(insuranceScheme);
	}
	else {
		throw new EmployeeException("please re-enter your salary or designation");
	}

	//System.out.println(emp1);
	return emp1;
}


	
}
