package com.cg.eis.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator {
	public boolean validateName (String name) {
		  
		  Pattern  pattern=Pattern.compile("[A-Z][a-z]{4,}");
		  Matcher mat=pattern.matcher(name);
		  return mat.matches();
		  
	     }
	public boolean validatedesignation (String Designation) {
		  
		  if(Designation.equals("System Associate")||Designation.equals("Programmer")|| Designation.equals("Manager")||Designation.equals("Clerk"))
		  return true;
	      return false;
			  
	}
	public boolean validateInsuranceScheme (String InsuranceScheme ) {
		  
		  if(InsuranceScheme .equals("Scheme C")||InsuranceScheme .equals("Scheme B")|| InsuranceScheme .equals("Scheme A")||InsuranceScheme .equals("No Scheme"))
		  return true;
	      return false;
			  
	}
	public boolean validateEmpID (String id) { 
		  
		  Pattern  pattern=Pattern.compile("[0-9]{6}");
		  Matcher mat=pattern.matcher(id);
		  return mat.matches();
				  
				  
	 }
	public boolean validatesalary (String Salary) { 
		if(Salary .equals(">5000 and < 20000")||Salary .equals(">=20000 and <40000")||Salary .equals(">=40000")||Salary .equals("<5000"))
			  return true;
		      return false;
				  
			
	}
}
