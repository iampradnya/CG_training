package com.cg.eis.bean;


import com.cg.eis.exception.EmployeeException;

public class Employee {

	private String empID;
	private String name;
	private int salary;
	private String designation;
	private String InsuranceSceme;
	
	public String getEmpID() {
		return empID;
	}

	public void setEmpID(String empID) {
		this.empID = empID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsuranceSceme() {
		return InsuranceSceme;
	}

	public void setInsuranceSceme(String insuranceSceme) {
		InsuranceSceme = insuranceSceme;
	}

	@Override
	public  String toString() {
		return empID+"" +name+"" +salary+"" +designation+"" +InsuranceSceme+"" ;
	}

	
}
