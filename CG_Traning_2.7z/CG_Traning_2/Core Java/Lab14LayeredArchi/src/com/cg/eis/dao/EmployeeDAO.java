package com.cg.eis.dao;

import java.util.List;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.bean.Employee;

public interface EmployeeDAO {
	
	public Employee AddEmployee (Employee emp) throws Exception;
	public List<Employee> getInsuranceScheme()  throws Exception;
	public Employee getEmployee(String empid) throws Exception;
	public List<Employee> getEmployees();

 
}
