package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface EmployeeService {

	public Employee AddEmployee (Employee emp) throws Exception;
	public List<Employee> getInsuranceScheme()  throws Exception;
	public Employee getEmployee(String empid) throws Exception;
	public List<Employee> getEmployees();
	


}
