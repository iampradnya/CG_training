import java.lang.reflect.Array;
import java.util.Arrays;

public class ReverseSort {
	
	public void getSorted(int array[])
	{
		//convert int array to string
	
	String reverse="";
	int len=array.length;
	String[] arr=new String[len];
	for (int i=0;i<array.length;i++)
	{
		int temp=array[i];
		String temp1=Integer.toString(temp);
		arr[i]=temp1;
		
	}
	//reverse the elements
	for (int j=0;j<array.length;j++)
	{
		String temp=arr[j];
		for(int i=temp.length()-1;i>=0;i--)
		{
			reverse=reverse+temp.charAt(i);
		}
		arr[j]=reverse;
		reverse="";
	}
		//convert string array to int array
		for(int i=0;i<arr.length;i++)
		{
			String m=arr[i];
			int k=Integer.valueOf(m);
			array[i]=k;
		}
		
		//sort the array
		Arrays.sort(array);
		
		//display the array
		for(int m=0;m<array.length;m++)
		{
			System.out.println(array[m]);
		}
		
		public static void main(String[] args)
		}
	
	}

