package com.cg.ams.test;

public class TestClass {

}
