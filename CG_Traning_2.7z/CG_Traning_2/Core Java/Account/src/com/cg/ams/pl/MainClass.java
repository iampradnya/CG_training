package com.cg.ams.pl;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.cg.ams.service.BankAccountService;
import com.cg.ams.service.BankAccountServiceImpl;
import com.cg.ams.dto.BankAccount;
import com.cg.ams.exception.BankAccountException;

public class MainClass 
{
	static int accno=112200;
	DatabaseConnection db=new DatabaseConnection();

	public static void main(String[] args) throws SQLException, IOException 
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		BankAccount ba = null; 
		Scanner scanner=new Scanner(System.in);
		BankAccountService service=new BankAccountServiceImpl();
		for(;;)
		{

			System.out.println("WELCOME!"
					+ "\n1. Add account\n2. Withdraw Amount\n"
					+"3. Deposit Amount\n4. Fund Transfer\n5. Print All Transactions"
					+"\n6. Show Current Balance\n7. Exit");
			System.out.println("Enter Option:");
			int option=scanner.nextInt();

			switch(option)
			{

			case 1:
				try
				{

					ba=acceptDetails();
					ba=service.addAccount(ba);
					System.out.println(dtf.format(now));  
					System.out.println("Account added!!");
					System.out.println("...............................");
					System.out.println("Your Account number is: "+ba.getAcc_no());
					System.out.println("Name:" +ba.get_name());
					System.out.println("Phone Number:" +ba.getPhone_no());
					System.out.println("Address:" +ba.getAddress());
					System.out.println("Initial Balance:" +ba.getBalance());
				}
				catch (BankAccountException be) 
				{
					System.out.println(be.getMessage());
				}

				break;

			case 2:
				try 
				{
					System.out.println("Enter Your Account number:");
					int accno=scanner.nextInt();
					System.out.println("Enter Amount to withdraw:");
					double amount=scanner.nextDouble();
					boolean checkAccount=service.checkAccno(accno);
					//ba=service.getAccount(accno);
					//service.withdrawAmount(amount, ba);
					//ba.setTransactions("Withdrawn Rs."+amount+
					//	" from the account");
					if(checkAccount)
					{
						boolean withdrawStatus=service.withdrawAmount(amount, accno);
						if(withdrawStatus)
						{
							System.out.println(dtf.format(now));
							System.out.println("Withdraw Successful");
							System.out.println("Balance="+service.showBalance(accno));
						}
						else
						{
							System.out.println("Withdraw failed");
						}
					}
					else
					{
						System.out.println("entered account does not exist");
						System.out.println("..............................");
					}
				}


				catch (BankAccountException be) 
				{
					System.out.println(be.getMessage());
				}

				break;

			case 3:
				try 
				{
					System.out.println("Enter Your Account Number:");
					int accno=scanner.nextInt();
					System.out.println("Enter Amount to deposit:");
					double amount=scanner.nextDouble();
					boolean execute=service.checkAccno(accno);
					if(execute) {
						//ba=service.getAccount(accno);
						//service.depositAmount(amount, ba);
						//ba.setTransactions("Deposited Rs."+amount+
						//		" from the account");
						System.out.println(dtf.format(now));
						System.out.println("Deposit Successful");
						service.depositAmount(amount, accno);
						System.out.println("Balance="+service.showBalance(accno));
						System.out.println("Balance="+service.showBalance(accno));
					}else
					{
						System.out.println("entered account does not exist");
						System.out.println(".............................");

					}
				}
				catch (BankAccountException be) 
				{
					System.out.println(be.getMessage());
				}

				break;

			case 4:
				try 
				{
					System.out.println("Enter Account number of sender:");
					int fromacc=scanner.nextInt();
					System.out.println("Enter Amount to transfer:");
					int amount=scanner.nextInt();
					System.out.println("Enter Account no of receiver:");
					int toacc=scanner.nextInt();
					boolean accountExisting=service.checkAccno(toacc);
					//ba=service.getAccount(accno);
					//BankAccount ac=service.getAccount(toacc);
					if(accountExisting)
					{
						boolean checkStatus=service.fundTransfer(amount, fromacc, toacc);
						if(checkStatus)
						{
							//ba.setTransactions("Transferred Rs."+amount+
							//" from the account to "+ac.get_name());
							System.out.println(dtf.format(now));
							System.out.println("Transfer Successful");
							System.out.println("Balance="+service.showBalance(fromacc));
						}
						else
							System.out.println("Transfer Falied!");
					}
					else
					{
						System.out.println("entered account does not exist");
						System.out.println(".............................");

					}
				}
				catch (BankAccountException be) 
				{
					System.out.println(be.getMessage());
				}

				break;

			case 5:
				try {
					System.out.println("Enter the account number :");
					int accno=scanner.nextInt();
					boolean execute=service.checkAccno(accno);
					if(execute)
					{
						String print_transaction=service.printTransactions(accno);
						System.out.println(print_transaction);

					}else
					{
						System.out.println("entered account does not exist");
						System.out.println(".............................");

					}
				}
				catch(BankAccountException e) {
					System.out.println(e.getMessage());
				}catch(NullPointerException ex) {
					System.out.println("Invalid account.");
				}catch(InputMismatchException exc) {
					System.out.println("Invalid Account");
				}
				break;

				//				try 
				//				{
				//					System.out.println("Enter Your Account Number:");
				//					int accno=scanner.nextInt();
				//					ba=service.getAccount(accno);
				//					//String transaction=service.printTransactions(ba);
				//					//for(String str:transaction)
				//					{
				//						System.out.println(dtf.format(now));
				//						System.out.println(str+"\n");
				//					}
				//				}
				//				catch (BankAccountException be) 
				//				{
				//					System.out.println(be.getMessage());
				//				}
				//				
				//				break;
				//			
			case 6:
				try
				{
					System.out.println("Enter Your Account Number:");
					int accno=scanner.nextInt();
					//ba=service.getAccount(accno);
					boolean execute=service.checkAccno(accno);
					if(execute)
					{
						double available=service.showBalance(accno);
						System.out.println("Current Balance is Rs. " +available);
					}else
					{
						System.out.println("entered account does not exist");
						System.out.println(".............................");

					}
				}
				catch(BankAccountException be)
				{
					System.out.println(be.getMessage());
				}

				break;

			case 7:
				System.out.println("Thank You!!!!!!!!!!!!!!!!!!!!!!");
				System.exit(0);

			default:
				System.out.println("Invalid Input");
			}
		}
	}


	public static BankAccount acceptDetails() throws BankAccountException, SQLException, IOException
	{
		BankAccountService service=new BankAccountServiceImpl();
		BankAccount ba=new BankAccount();
		Scanner scanner=new Scanner(System.in);

		System.out.println("Enter Your Name:");
		String name=scanner.nextLine();
		ba.set_name(name);
		System.out.println("Enter Phone Number:");
		String phn_no=scanner.next();
		ba.setPhone_no(phn_no);
		System.out.println("Enter Address:");
		String address=scanner.next()+scanner.nextLine();
		ba.setAddress(address);
		System.out.println("Enter Initial Balance:");
		double bal=scanner.nextDouble();
		ba.setBalance(bal);

		int last_acc=service.lastAccount();
		ba.setAcc_no(++last_acc);

		return ba;
	}

}
