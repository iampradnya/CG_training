package com.cg.ams.exception;

public class BankAccountException extends Exception 

{
	public BankAccountException(String str)
	
	{
		super(str);
	}
}
