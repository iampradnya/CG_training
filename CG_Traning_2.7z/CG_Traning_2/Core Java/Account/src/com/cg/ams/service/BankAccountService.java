package com.cg.ams.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.ams.dto.BankAccount;
import com.cg.ams.exception.BankAccountException;

public interface BankAccountService 

{

	//methods declaration
	public BankAccount addAccount(BankAccount ba) throws BankAccountException, SQLException, IOException;
	
	public boolean depositAmount(double amount, int accno) throws BankAccountException, IOException, SQLException;
	
	public boolean withdrawAmount(double amount, int accno) throws BankAccountException, IOException, SQLException;
	
    public boolean fundTransfer(double amount, int fromacc, int toacc) throws BankAccountException, IOException, SQLException;
	
	public String printTransactions(int accno) throws BankAccountException, SQLException, IOException;
	
	public boolean checkAccno(int accno) throws BankAccountException, SQLException, IOException;
	
	public BankAccount getAccount(int accno) throws BankAccountException, IOException;

	public int lastAccount() throws BankAccountException, SQLException, IOException;

	public double showBalance(int accno) throws BankAccountException, IOException, SQLException;



	



	

	

	


	


	


	
	
}
