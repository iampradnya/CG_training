package com.cg.ams.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import com.cg.ams.dao.BankAccountDAOImpl;
import com.cg.ams.dto.BankAccount;
import com.cg.ams.exception.BankAccountException;
import com.cg.ams.service.DataValidator;

class TestClassTest {
	
	DataValidator validate = new DataValidator();
	BankAccountDAOImpl dao = new BankAccountDAOImpl();
	
	
	@Test
	public void testName1()//test case for valid name
	{
	assertTrue(validate.validateName("Pradnya"));
	}
	
	
	@Test
	public void testPhoneNo1()//test case for valid phone number
	{
	assertTrue(validate.validatePhoneNo("7506760997"));
	}
	
	
	@Test
	public void testPhoneNo2()//test case for valid phone number
	{
	assertTrue(validate.validatePhoneNo("9594958032"));
	}
	
	
	@Test
	public void testPhoneNo3()//test case for valid phone number
	{
	assertTrue(validate.validatePhoneNo("9769251256"));
	}
	
	
	@Test
	public void testAccNo()//test case for valid account number
	{
	assertTrue(validate.validateAccNo(876554));
	}
	
	public void testAddAccount() throws IOException, SQLException	{
	BankAccount ba= new BankAccount(112215,"Pradnya","7506760997","Mumbai",19800, null);
	try {
	assertNotNull(dao.addAccount(ba));
	}
	catch(BankAccountException e) {
	System.out.println("Error occured in testing addAccount");
	}
	}


}
