package com.cg.ams.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import com.cg.ams.dto.BankAccount;
import com.cg.ams.exception.BankAccountException;
import com.cg.ams.pl.DatabaseConnection;

/**
 * Author name:Pradnya Patil
 * @author ppati100
 *Mail Id:pradnya.f.patil@capgemini.com
 *Version:1.0
 *Description:Dao class to perform CRUD operations on hashmap
 *Date:!20-july-2019
 */



public class BankAccountDAOImpl implements BankAccountDAO 
{

	private static Map<Integer,BankAccount> accounts=new HashMap<>();



	//method declaration of interface
	@Override
	public BankAccount addAccount(BankAccount ba) throws BankAccountException, SQLException, IOException 
	{
		Connection con = DatabaseConnection.getConnection();
		try {
			String sql="insert into bank_account (acc_no,name,phone_no,address,balance)"
					+" values(?,?,?,?,?)";

			PreparedStatement ps=con.prepareStatement(sql);

			System.out.println();
			ps.setInt(1, ba.getAcc_no());
			ps.setString(2, ba.get_name());
			ps.setString(3, ba.getPhone_no());
			ps.setString(4, ba.getAddress());
			ps.setInt(5, (int) ba.getBalance());
			//BankAccount.getAcc_no();
			int row=ps.executeUpdate();
			//System.out.println(row + " inserted....");
			//System.out.println("Your Account number is:" +ba.getAcc_no());
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}

		return ba;
	}



	@Override
	public boolean depositAmount(double amount, int accno) throws BankAccountException, IOException, SQLException 
	{
		Connection conn=DatabaseConnection.getConnection();
		BankAccount ba=new BankAccount();
		String date = null;

		double bal=showBalance(accno);
		double new_bal=bal+amount;
		try {
			String sql="update bank_account set balance=? where acc_no=? ";

			PreparedStatement ps=conn.prepareStatement(sql);

			ps.setDouble(1, new_bal);
			ps.setInt(2, accno);

			ResultSet res=ps.executeQuery();
			saveTransaction(accno, "Deposit", amount,"Deposit Successfull");



			//				while(res.next()) {
			//					
			//					
			//				}

		}catch(SQLException e) {
			e.printStackTrace();
		}

		return true;
	}



	@Override
	public boolean withdrawAmount(double amount, int accno) throws BankAccountException, IOException, SQLException 
	{

		Connection conn=DatabaseConnection.getConnection();
		BankAccount ba=new BankAccount();
		String date = null;

		double bal=showBalance(accno);
		double new_bal=bal-amount;
		try {
			String sql="update bank_account set balance=? where acc_no=? ";

			PreparedStatement ps=conn.prepareStatement(sql);

			ps.setDouble(1, new_bal);
			ps.setInt(2, accno);

			ResultSet res=ps.executeQuery();
			saveTransaction(accno, "Withdraw", amount,"Withdraw Successfull");
			//				while(res.next()) {
			//					
			//					
			//				}

		}catch(SQLException e) {
			e.printStackTrace();
		}

		return true;
	}



	@Override
	public boolean fundTransfer(double amount, int fromacc, int toacc)
			throws BankAccountException, IOException, SQLException {
		System.out.println(".........entered");
		if(withdrawAmount(amount,fromacc) && depositAmount(amount,toacc)) {
			System.out.println("entered in fund.......");
			return true;
		}
		else {
			return false;

		}
	}
	//	@Override
	//	public List<String> printTransactions(BankAccount ba) throws BankAccountException 
	//	{
	//		return ba.getTransactions();
	//	}



	@Override
	public double showBalance(int accno) throws BankAccountException, IOException, SQLException 
	{
		double balance=0;
		Connection con1=DatabaseConnection.getConnection();

		try {
			String sql="Select balance from bank_account where acc_no=?";
			PreparedStatement ps=con1.prepareStatement(sql);
			ps.setInt(1, accno);
			ResultSet res=ps.executeQuery();
			while(res.next()) 

				balance=res.getDouble("balance");


		} catch (Exception e) {



			e.printStackTrace();
		}

		return balance;
	}



	@Override
	public BankAccount getAccount(int acc_no) throws BankAccountException, IOException 
	{
		Connection conn=DatabaseConnection.getConnection();
		Statement st;
		try {
			st=conn.createStatement();
			ResultSet res=st.executeQuery("select acc_no,name,phone_no,address,balance from bank_account");
			while(res.next()) {
				int acc=res.getInt("acc_no");
				String name=res.getString("name");
				String address=res.getString("address");
				String phone_no=res.getString("phone_no");
				double balance=res.getDouble("balance");
				System.out.println(acc_no +""+name+""+address+""+phone_no+"" +balance);

			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return accounts.get(acc_no);

	}



	public int lastAccount() throws BankAccountException, SQLException, IOException {

		Connection con1 = DatabaseConnection.getConnection();
		int accno=112200;
		Statement st=con1.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		String sql="Select acc_no from bank_account";
		ResultSet res=st.executeQuery(sql);
		while(res.next()) {

		}

		if(res.isAfterLast()) 
		{

			res.previous();
			accno=res.getInt(1);
		}

		return accno;
	}



	@Override
	public String printTransactions(int accno) throws BankAccountException, SQLException, IOException {
		Connection con1 = DatabaseConnection.getConnection();
		String transaction_done="";
		PreparedStatement ps=con1.prepareStatement("select * from transaction where acc_no=?");
		ps.setInt(1, accno);
		ResultSet res=ps.executeQuery();
		System.out.println("Transaction_id\tTransaction_type\tTransaction Amount\tDateTime\t\tTransaction_status");
		while(res.next()) {
			transaction_done=transaction_done+res.getInt("transaction_id") +"\t";
			//transaction_done=transaction_done+res.getInt("acc_no")+"\t";
			transaction_done=transaction_done+res.getString("transaction_type")+" \t\t";
			transaction_done=transaction_done+res.getDouble("transaction_amount")+" \t\t\t";
			transaction_done=transaction_done+res.getString("transaction_date_time")+"\t";
			transaction_done=transaction_done+res.getString("transaction_status")+"\n";
		}
		return transaction_done;
	}




	public void saveTransaction(int accno, String history, double amount, String status) throws BankAccountException, IOException {
		try {
			Connection con1 = DatabaseConnection.getConnection();
			PreparedStatement ps=con1.prepareStatement("insert into transaction values(?,?,?,?,?,?)");

			ps.setInt(1, Math.abs(new Random().nextInt()));
			ps.setInt(2, accno);
			ps.setString(3, history);
			ps.setDouble(4, amount);
			ps.setString(5, gettime());
			ps.setString(6, status);
			int history1=ps.executeUpdate();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}

	}



	private String gettime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();
		String a=dtf.format(now);
		return a;

	}



	@Override
	public boolean checkAccno(int accno) throws BankAccountException, SQLException, IOException {
		boolean check = false;
		Connection con1 = DatabaseConnection.getConnection();
		String sql="select * from bank_account where acc_no=?";
		PreparedStatement st=con1.prepareStatement(sql);
		st.setInt(1,accno);
		ResultSet rs=st.executeQuery();
		if(rs==null)
		{
			throw new BankAccountException("Entered account does not exist");
		}
		else
		{
			while(rs.next())
			{
				check=true;
			}
		}
		return check;



	}



}
