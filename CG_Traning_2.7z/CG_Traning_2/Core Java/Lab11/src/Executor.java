import java.time.LocalTime;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Executor implements Callable<Integer>{

	@Override
	public Integer call() throws Exception {
		int n=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of times you want to repeat the timer");
		String s=sc.nextLine();
		n=Integer.parseInt(s);
		if(n>0) {
			for(int i=1;i<=n;i++) {
			LocalTime time=LocalTime.now();
			System.out.println(time);
			Thread.sleep(10000);
			}
		}
		return n;
	}

	public static void main(String[] args) throws InterruptedException,ExecutionException{
		
		
			Callable<Integer> task=new Executor();
			ExecutorService st=Executors.newFixedThreadPool(5);
			Future<Integer> result=st.submit(task);
			Integer value=result.get();
			System.out.println(value);
	}
		
		
	}

