import java.util.concurrent.Executors;
import java.util.concurrent.Executor;

public class FileProgram {
	
	
	public static void main(String[] args) {
		Executor executor= Executors.newSingleThreadExecutor();
		CopyDataThread cdt=new CopyDataThread();
		executor.execute(cdt);
	}


}
