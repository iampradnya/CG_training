import java.util.Scanner;

public class Ex4Power {
	int i=0;
	double res=0;
	boolean checkNumber(int n) {
		if(n%2==0)
		{
			while(n>res)
			{
				res=Math.pow(2, i);
				i++;
			}
			if(n == res)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	public static void main(String[] args) {
		Ex4Power obj=new Ex4Power();
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of n:");
		String s= sc.nextLine();
	    try {
	    n=Integer.parseInt(s);
	    if(n>=0) {
	    	boolean result=obj.checkNumber(n);
	    	if(result==true) {
	    		System.out.println(n+" is a power of 2");
	    	}
	    	else
	    		System.out.println(n+" is not a power of 2");
	    }
	    else 
	    {
	    	System.out.println("Enter a positive integer number");
	    }
	    
	}
	   
		catch(NumberFormatException e) {
		
			System.out.println("Enter a valid natural number");
			
		}
	}

}
