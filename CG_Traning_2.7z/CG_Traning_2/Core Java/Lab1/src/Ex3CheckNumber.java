import java.util.Scanner;

public class Ex3CheckNumber {
	boolean checkNumber(int number)
	{
		boolean flag=true;
		int currDigit=number%10;
		number=number/10;
		while(number>0) {
			
			if(currDigit < number%10) {
				flag=false;
				break;
				
			}
			currDigit=number%10;
			number=number/10;
			
		}
		if(flag) {
			return true;
		}
		else
			return false;
	}
public static void main(String[] args) {
		Ex3CheckNumber obj= new Ex3CheckNumber();
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of n::");
		String s= sc.nextLine();
	    try {
	    n=Integer.parseInt(s);
	    if(n>=0) {
	    	boolean res=obj.checkNumber(n);
	    	if(res==true) {
	    		System.out.println("It is an increasing number");
	    	}
	    	else
	    		System.out.println("It is not an increasing number");
	    }
	    else 
	    {
	    	System.out.println("Enter a positive integer number");
	    }
	    
	}
	   
		catch(NumberFormatException e) {
		
			System.out.println("Enter a valid natural number");
			
		}
	}

}
