
import java.util.Scanner;

public class Ex1CalculateSum {
	int calculateSum(int n)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
		{
			if(i%3==0||i%5==0) {
				sum=sum+i;
			}
		}
		return sum;
	}
	public static void main(String[] args){
		
		Ex1CalculateSum obj=new Ex1CalculateSum();
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of n:");
		String s= sc.nextLine();
	    try {
	    n=Integer.parseInt(s);
	    if(n>=0) {
	    	System.out.println("Sum is " +obj.calculateSum(n));
	
	    }
	    else 
	    {
	    	System.out.println("Enter a positive integer number");
	    }
	    
	}
	   
		catch(NumberFormatException e) {
		
			System.out.println("Enter a valid natural number");
			
		}
	}
}
