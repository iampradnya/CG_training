import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread extends Thread {

	@Override
	public void run() {

		try {
			FileReader fr = new FileReader(
					"C:\\Users\\ppati100\\Documents\\training\\Source.txt");
			BufferedReader br = new BufferedReader(fr);
			FileWriter fw = new FileWriter(
					"C:\\Users\\ppati100\\Documents\\training\\target.txt", true);
			int s;
			int count = 0;
			while ((s = br.read()) != -1) {
				if (count == 10) {
					System.out.println("Ten characters copied");
					fw.write('0');
					count = 0;
					sleep(5000);
				}
				char c = (char) s;
				fw.write(c);
				count++;
			}
			fw.flush();
			br.close();
			fw.close();
			System.out.println("file copied");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
