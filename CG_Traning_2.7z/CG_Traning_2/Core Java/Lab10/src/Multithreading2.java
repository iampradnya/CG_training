import java.sql.Time;
import java.time.LocalTime;
import java.util.Scanner;
import java.util.Timer;


public class Multithreading2 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			
		int n=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of threads");
		//String s=sc.nextLine();
		//n=Integer.parseInt(s);
		int no=sc.nextInt();
		for(int i=1;i<=no;i++)
		{
			LocalTime time=LocalTime.now();
			System.out.println(time);
			Thread.sleep(10000);
		}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			
			
			System.out.println("Thread is interupted when is sleeping" +e);
			
		}
		
	}
	
	public static void main(String[] args) {
		 Multithreading2 Multhread=new  Multithreading2();
		 Thread t=new Thread(Multhread);
		 t.start();
	}

	

}
