
public class FileProgram {
	
	public static void main(String[] args) {
		
		CopyDataThread cdt= new CopyDataThread();
		cdt.start();
	}

}
