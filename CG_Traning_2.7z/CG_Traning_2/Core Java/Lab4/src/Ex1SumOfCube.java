import java.util.*;
public class Ex1SumOfCube {
	public int Sum(int n) {
		int sum=0;
		while(n>0)
		{
			/*int c=n%10;
			System.out.println("cube of"+c+"is"+(c*c*c));
			sum+=c*c*c;
			c=n/10;
			System.out.println("the sum of cube is"+sum);*/
			
			
			int c=n%10;
			int b=c*c*c;
			sum+=b;
			n=n/10;
		}
		System.out.println("Sum of the cube of the digit is:"+sum);
		return sum;
		}
	public static void main (String[] args) {
		try {
			Ex1SumOfCube sc=new Ex1SumOfCube();
			sc.Sum(121);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
