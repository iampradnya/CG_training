package com.cg.productmgmt.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import com.cg.productmgmt.exception.ProductException;

/**
 * Author name:Pradnya Patil
 * @author ppati100
 *Mail Id:pradnya.f.patil@capgemini.com
 *Version:1.0
 *Description:Dao class to perform CRUD operations on hashmap
 *Date:!12-july-2019
 */

//Class to perform data accessing logic
public class ProductDao implements IProductDao {

	// map for productName as key and productCategory as value
	static Map<String, String> productDetails;
	// map for productName as key and price as value
	static Map<String, Integer> salesDetails;

	// static block to add details in map
	static {
		productDetails = new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");

		salesDetails = new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);
	}
	

/**
 * Method Description:Update method will have category
 * and hike rate as input and it will update the price of all the product
 * from same category
 * if invalid category is given , then ProductException will be thrown  
 */

	//method to updateproducts
	@Override
	public int updateProducts(String category, int hike) throws ProductException {
		int price, hikeValue, newPrice, count = 0;
		
		List<String> updateList = new ArrayList<String>();
		
		
		
		Set<Entry<String, String>> list1 = productDetails.entrySet();
		
		
		Iterator<Entry<String, String>> itr1 = list1.iterator();
		//iterating in the productdetails
		
		while (itr1.hasNext()) {
			Entry<String, String> element = itr1.next();
			//adding products to be` updated in List
			if (element.getValue().equals(category)) {
				updateList.add(element.getKey());
				
				System.out.println(element.getKey());
			}
		}
		//checking if list is empty
		if (updateList.isEmpty()) {
			throw new ProductException("No products availabe to update");
		} else {
			//updating the hike value for the above category
			for (String s : updateList) {
				
				if (salesDetails.containsKey(s)) {
					price = salesDetails.get(s);
					
					hikeValue = (price * hike) / 100;
					
					newPrice = hikeValue + price;
					
					salesDetails.replace(s, newPrice);
					count++;
				}
			}
		}
		return count;

	}

	//getting salesdetails
	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		return salesDetails;
	}

}
