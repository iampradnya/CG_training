package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.IProductDao;
import com.cg.productmgmt.dao.ProductDao;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.validation.DataValidator;



//class to perform business operations
public class ProductService implements IProductService {

	// creating object of ProductDao referencing IProductDao interface

	IProductDao dao;
	DataValidator validator;

	// constructor for initializing objects
	public ProductService() {
		dao = new ProductDao();
		validator = new DataValidator();
	}

	@Override
	public int updateProducts(String category, int hike) throws ProductException {
		// validating hike input
		if (!validator.validateHike(hike)) {
			try {
				throw new ProductException("Hike rate should be above 0");
			} catch (ProductException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}
		// validating product category
		if (!validator.validateProductCategory(category)) {
			try {
				throw new ProductException("above category does not exist");
			} catch (ProductException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

		else {
			return dao.updateProducts(category, hike);
		}
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {

		return dao.getProductDetails();
	}
	

}
