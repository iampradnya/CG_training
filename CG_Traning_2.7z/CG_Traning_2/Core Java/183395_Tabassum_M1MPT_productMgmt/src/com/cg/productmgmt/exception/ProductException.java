package com.cg.productmgmt.exception;


public class ProductException extends Exception {

	// default constructor
	public ProductException() {

	}

	// parameterized constructor
	public ProductException(String message) {
		super(message);
	}
	
}
