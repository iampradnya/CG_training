package com.cg.productmgmt.ui;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client {

	public static void main(String[] args) throws ProductException {
		// TODO Auto-generated method stub
		IProductService service = new ProductService();
		do {
			//displaying menu
			System.out.println("Enter a particular option:");
			System.out.println("1)Update Product Price");
			System.out.println("2)Display Product List");
			System.out.println("3)Exit");
			
			//defining scanner object to take input from console
			Scanner sc= new Scanner(System.in);
			int option = 0;
			try {
				option = sc.nextInt();
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				System.out.println("value should be a integer value");
			}
			switch(option)
			{
			case 1:
				//getting category and hike rate from user
				System.out.println("Enter the Product Category: ");
				String category=sc.next();
				
				System.out.println("Enter hike Rate");
				int hike=sc.nextInt();
				
				try {
					//send the values to service class to operate
					int value=service.updateProducts(category, hike);
					System.out.println(value+"products updated");
				} catch (ProductException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				break;
			case 2:
				//diplaying thhe product list
				
				Map<String,Integer> newSalesDetails = new HashMap<String,Integer>();
				newSalesDetails=service.getProductDetails();
				
				System.out.println(newSalesDetails);
				break;
			
			case 3:
				//exiting the application
				sc.close();
				System.exit(0);
			
			default:
				System.out.println("please enter a valid option");
				break;
			}
		} while (true);
	}

	

}
