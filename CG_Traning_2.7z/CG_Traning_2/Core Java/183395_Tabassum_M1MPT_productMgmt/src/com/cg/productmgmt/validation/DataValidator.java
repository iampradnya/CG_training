package com.cg.productmgmt.validation;

public class DataValidator {

	//validation method for hike<=0
	public boolean validateHike(int hike) {
		if (hike <= 0) {
			return false;
		} else {
			return true;
		}

	}

	//validation for category input
	public boolean validateProductCategory(String category) {
		if (category.equalsIgnoreCase("soap") || category.equalsIgnoreCase("paste")
				|| category.equalsIgnoreCase("electronics") || category.equalsIgnoreCase("cosmatics")) {
			return true;
		} else {
			return false;
		}
	}

}
