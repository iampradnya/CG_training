package com.cg.productmgmt.bean;

public class Product {

	// defining properties
	private String productName;
	private String productCatgory;
	private int price;

	// getters and setters
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCatgory() {
		return productCatgory;
	}

	public void setProductCatgory(String productCatgory) {
		this.productCatgory = productCatgory;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	// toString method to print data
	@Override
	public String toString() {
		return "Product [productName=" + productName + ", productCatgory=" + productCatgory + ", price=" + price + "]";
	}

}
