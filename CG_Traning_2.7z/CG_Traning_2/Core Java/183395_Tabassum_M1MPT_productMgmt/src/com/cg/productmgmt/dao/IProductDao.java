package com.cg.productmgmt.dao;

import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

//interface to define data accessing logic
public interface IProductDao {

	// updating Product details method defination
	public int updateProducts(String category, int hike) throws ProductException;

	// getting product detail method defination
	public Map<String, Integer> getProductDetails() throws ProductException;
}
