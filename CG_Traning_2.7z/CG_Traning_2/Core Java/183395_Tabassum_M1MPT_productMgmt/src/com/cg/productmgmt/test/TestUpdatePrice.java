package com.cg.productmgmt.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

class TestUpdatePrice {

	@Test
	void test() throws ProductException {
		String category="soap";
		int hike = 7;
		
		IProductService service = new ProductService();
		
		int res = service.updateProducts(category, hike);
		
		boolean value;
		if (res < 0) {
			value = false;
		} else {
			value = true;
		}
		assertTrue("Product updation failed", value);
	}

}
