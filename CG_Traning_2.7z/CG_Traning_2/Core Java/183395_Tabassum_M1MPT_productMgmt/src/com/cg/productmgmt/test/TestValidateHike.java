package com.cg.productmgmt.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.productmgmt.validation.DataValidator;

class TestValidateHike {

	@Test
	void test() {
		int hike=5;
		DataValidator validate= new DataValidator();
		boolean result=validate.validateHike(hike);
		assertTrue("Hike value should be greater than 0",result);
	}

}
