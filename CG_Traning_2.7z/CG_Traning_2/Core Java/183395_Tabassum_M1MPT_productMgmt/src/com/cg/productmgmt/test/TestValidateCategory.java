package com.cg.productmgmt.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.productmgmt.validation.DataValidator;

class TestValidateCategory {

	@Test
	void test() {
		String category="electronics";
		DataValidator validate= new DataValidator();
		boolean result=validate.validateProductCategory(category);
		assertTrue("please enter a valid category",result);
	}

}
