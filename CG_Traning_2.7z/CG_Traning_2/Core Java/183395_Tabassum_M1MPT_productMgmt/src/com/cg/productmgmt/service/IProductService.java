package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

//interface to define business logic
public interface IProductService {
	// updating Product details method defination
	public int updateProducts(String category, int hike) throws ProductException;

	// getting product detail method defination
	public Map<String, Integer> getProductDetails() throws ProductException;

}
