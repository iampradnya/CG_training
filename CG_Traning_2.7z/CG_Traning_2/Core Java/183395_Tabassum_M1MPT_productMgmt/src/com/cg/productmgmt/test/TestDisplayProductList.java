package com.cg.productmgmt.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

class TestDisplayProductList {

	@Test
	void test() throws ProductException {
		IProductService service = new ProductService();
		
		Map<String, Integer> map1 = new HashMap<>();
		
		map1 = service.getProductDetails();
		
		System.out.println(map1);
		
		
		boolean value;
		if (map1 == null) {
			value = false;
		} else {
			value = true;
		}
		assertTrue("product list display method failed", value);
	}

}
