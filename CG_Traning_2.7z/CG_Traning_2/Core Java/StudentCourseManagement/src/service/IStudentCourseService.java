package service;

import java.util.List;

import bean.Course;
import bean.Student;
import exception.StudentCourseException;

public interface IStudentCourseService {
	public Student acceptStudentDetails(Student st) throws StudentCourseException;

	public Student enrollToCourse(String rollno,String courseId) throws StudentCourseException;

	public List<String> getNoOfStudentInCourse(String coursecode) throws StudentCourseException;

	public Student updateStudent(Student student) throws StudentCourseException;
	public List<Course> getCourseDetail() throws StudentCourseException;
}
