package service;

import java.util.List;

import bean.Course;
import bean.Student;
import dao.IStudentCourseDao;
import dao.IStudentCourseDaoImpl;
import exception.StudentCourseException;
import validator.DataValidator;

public class IStudentCourseServiceImpl implements IStudentCourseService {

	IStudentCourseDao dao;
	DataValidator validator;

	public IStudentCourseServiceImpl() {
		dao = new IStudentCourseDaoImpl();
		validator = new DataValidator();
	}

	@Override
	public Student acceptStudentDetails(Student st) throws StudentCourseException {

		if (validator.validateRollNo(st.getRollno()) == false) {
			try {
				throw new StudentCourseException("Roll no should be six digit");
			} catch (StudentCourseException e) {
				// TODO Auto-generated catch block
				throw e;
			}
		} else if (validator.validateName(st.getName()) == false) {
			try {
				throw new StudentCourseException(
						"name should contain an first character uppercase and atleast 4 characters ");
			} catch (StudentCourseException e) {
				// TODO Auto-generated catch block
				throw e;
			}
		} else if (validator.validateCity(st.getAddress()) == false) {
			try {
				throw new StudentCourseException("City allowed are Mumbai, pune , banglore and chennai");
			} catch (StudentCourseException e) {
				// TODO Auto-generated catch block
				throw e;
			}
		} else if (validator.validateMobileNo(st.getMobileNumber()) == false) {
			try {
				throw new StudentCourseException("Mobile number should be 10 digit");
			} catch (StudentCourseException e) {
				// TODO Auto-generated catch block
				throw e;
			}
		} else {
			return dao.acceptStudentDetails(st);
		}
	}

	@Override
	public Student enrollToCourse(String rollno, String courseId) throws StudentCourseException {
		if (validator.validateRollNo(rollno) == false) {
			try {
				throw new StudentCourseException("Roll no should bw six digit");
			} catch (StudentCourseException e) {
				// TODO Auto-generated catch block
				throw e;
			}
		} else {
			return dao.enrollToCourse(rollno, courseId);
		}
	}

	@Override
	public List<String> getNoOfStudentInCourse(String coursecode) throws StudentCourseException {
		// TODO Auto-generated method stub
		if(validator.validateCourseCode(coursecode)==false)
		{
			try {
				throw new StudentCourseException("Course code does not exist");
			} catch (StudentCourseException e) {
				// TODO Auto-generated catch block
				throw e;
			}
		}
		else
		{
		return dao.getNoOfStudentInCourse(coursecode);}
	}

	@Override
	public Student updateStudent(Student st) throws StudentCourseException {
		if (validator.validateRollNo(st.getRollno()) == false) {
			try {
				throw new StudentCourseException("Roll no should be six digit");
			} catch (StudentCourseException e) {
				throw e;
			}
		} else if (validator.validateName(st.getName()) == false) {
			try {
				throw new StudentCourseException(
						"name should contain an first character uppercase and atleast 4 characters ");
			} catch (StudentCourseException e) {
				throw e;
			}
		} else if (validator.validateCity(st.getAddress()) == false) {
			try {
				throw new StudentCourseException("City allowed are Mumbai, pune , banglore and chennai");
			} catch (StudentCourseException e) {
				throw e;
			}
		} else if (validator.validateMobileNo(st.getMobileNumber()) == false) {
			try {
				throw new StudentCourseException("Mobile number should be 10 digit");
			} catch (StudentCourseException e) {
				throw e;
			}
		} else {
		return dao.updateStudent(st);
		}
	}

	@Override
	public List<Course> getCourseDetail() throws StudentCourseException {
		return dao.getCourseDetail();
	}

}
