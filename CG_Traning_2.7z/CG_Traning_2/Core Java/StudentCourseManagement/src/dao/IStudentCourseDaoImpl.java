package dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bean.Course;
import bean.Student;
import exception.StudentCourseException;

public class IStudentCourseDaoImpl implements IStudentCourseDao {

	private static Map<String, Student> student = new HashMap<String, Student>();
	private static Map<String, Course> course = new HashMap<String, Course>();

	static {
		course.put("1001", new Course("1001", "IT", "3 years", "55K"));
		course.put("1002", new Course("1002", "CS", "3 years", "50K"));
		course.put("1003", new Course("1003", "Aeronautics", "4 years", "99K"));
		course.put("1004", new Course("1004", "Architecture", "4 years", "99.9K"));
	}

	@Override
	public Student acceptStudentDetails(Student st) throws StudentCourseException {
		if (student.containsKey(st.getRollno())) {
			try {
				throw new StudentCourseException("student with similar rollno already exist");
			} catch (StudentCourseException e) {
				throw e;
			}
		} else {
			student.put(st.getRollno(), st);
			return st;
		}
	}

	@Override
	public Student enrollToCourse(String rollno, String courseId) throws StudentCourseException {
		if (student.containsKey(rollno) && course.containsKey(courseId)) {
			Student details = student.get(rollno);
			details.setCourseId(courseId);
			return details;
		} 
		else {
			try {
				throw new StudentCourseException("Please check your rollno and courseCode");
			} catch (StudentCourseException e) {
				throw e;
			}
		
		}
	}

	@Override
	public List<String> getNoOfStudentInCourse(String coursecode) throws StudentCourseException {
		Collection<Student> list = student.values();
		List<Student> studentList = new ArrayList<>(list);
		List<String> courseList = new ArrayList<>();
		for (Student s : studentList) {

			if (s.getCourseId().equals(coursecode)) {
				courseList.add(s.getName());
			}
			else if(s.getCourseId().equals(null))
			{
				throw new StudentCourseException("No student has enrolled to this course");
			}
		}
		return courseList;
	}

	@Override
	public Student updateStudent(Student stud) throws StudentCourseException {
		if (!student.containsKey(stud.getRollno())) {
			try {
				throw new StudentCourseException("Student not found");
			} catch (StudentCourseException e) {
				// TODO Auto-generated catch block
				throw e;
			}
		} else {
			student.replace(stud.getRollno(), stud);
			return stud;
		}
	}

	public List<Course> getCourseDetail() throws StudentCourseException {
		Collection<Course> list = course.values();
		List<Course> course = new ArrayList<>(list);
		return course;

	}

}
