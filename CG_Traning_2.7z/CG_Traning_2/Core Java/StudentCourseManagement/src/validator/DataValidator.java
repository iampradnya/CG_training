package validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.Student;

public class DataValidator {
public boolean validateName(String name) {
		
		Pattern pattern= Pattern.compile("[A-Z][a-z]{4,}");
		Matcher match=pattern.matcher(name);
		return match.matches();
	}
	public boolean validateMobileNo(String mobile) {

		Pattern pattern= Pattern.compile("[7-9][0-9]{9}");
		Matcher match=pattern.matcher(mobile);
		return match.matches();
	}
	public boolean validateCity(String location) {
		if(location.equalsIgnoreCase("Mumbai") || location.equalsIgnoreCase("chennai")|| location.equalsIgnoreCase("Pune")
	||location.equalsIgnoreCase("Banglore"))
			return true;
		else
			return false;
		
	}
	public boolean validateRollNo(String rollNo) {
		Pattern pattern= Pattern.compile("[0-9]{6}");
		Matcher match=pattern.matcher(rollNo);
		return match.matches();
	}
	
	
	public boolean validateCourseCode(String courseCode)
	{
		if(courseCode.equals("1001") || courseCode.equals("1002")||courseCode.equals("1003")||courseCode.equals("1004"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean validateList(List<Student> list)
	{
		if(list.isEmpty())
		{return true;}
		else
		{
			return false;
		}
		
	}

}
