package exception;

public class StudentCourseException extends Exception {
	public StudentCourseException() {
		super("some error occured");
	}

	public StudentCourseException(String message) {
		super(message);
	}
}
