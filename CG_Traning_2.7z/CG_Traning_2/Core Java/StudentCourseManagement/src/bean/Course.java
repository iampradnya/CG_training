package bean;

public class Course {
	private String courseCode;
	private String courseName;
	private String duration;
	private String fees;

	public Course(String string, String string2, String string3, String string4) {
		this.courseCode = string;
		this.courseName = string2;
		this.duration = string3;
		this.fees = string4;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getFees() {
		return fees;
	}

	public void setFees(String fees) {
		this.fees = fees;
	}

	@Override
	public String toString() {
		return "Course [courseCode=" + courseCode + ", courseName=" + courseName + ", duration=" + duration + ", fees="
				+ fees + "]";
	}

}
