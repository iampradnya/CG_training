package pl;

import java.util.List;
import java.util.Scanner;

import bean.Course;
import bean.Student;
import exception.StudentCourseException;
import service.IStudentCourseService;
import service.IStudentCourseServiceImpl;

public class MainClass {

	public static void main(String[] args) throws StudentCourseException {
		IStudentCourseService service = new IStudentCourseServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Enter option:");
			System.out.println("1)Add student details 2)enroll to a course");
			System.out.println("3)Display list of students for particular course");
			System.out.println("4)Update student details 5)Exit");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				Student s = acceptStudentDetails();
				try {
					s = service.acceptStudentDetails(s);
					System.out.println("Student added...");
				} catch (StudentCourseException e) {
					System.out.println(e.getMessage());
					
				}
				
				break;
			case 2:
				System.out.println("Enter your roll no");
				String rollno = sc.next();
				System.out.println("Enter courseCode to enroll to a course");
				List<Course> ls = service.getCourseDetail();
				for (Course c : ls) {
					System.out.println(c);
				}
				String courseId = sc.next();
				try {
					s = service.enrollToCourse(rollno, courseId);
					System.out.println("Enrolled to course successfully");
				} catch (StudentCourseException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					
				}
				
				break;
			case 3:
				List<Course> ls1 = service.getCourseDetail();
				for (Course c : ls1) {
					System.out.println(c);
				}
				System.out.println("To view no of students entrolled for a particular course ,please enter courseCode");
				String coursecode = sc.next();
				List<String> listt = null;
				try {
					listt = service.getNoOfStudentInCourse(coursecode);
					for (String ss : listt) {
						System.out.println(ss);
					}
				} catch (StudentCourseException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				break;
			case 4:
				s = acceptStudentDetails();
				try {
					s = service.updateStudent(s);
					System.out.println("Student details updated successfully");
				} catch (StudentCourseException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("invalid input");
				break;
			}
		} while (true);

	}

	private static Student acceptStudentDetails() {

		Student s = new Student();
		Scanner sc1 = new Scanner(System.in);

		System.out.println("Enter roll no");
		String rollno = sc1.next();
		s.setRollno(rollno);

		System.out.println("Enter student name");
		String name = sc1.next();
		s.setName(name);

		System.out.println("Enter city");
		String address = sc1.next();
		s.setAddress(address);

		System.out.println("enter mobileNo");
		String mobileNo = sc1.next();
		s.setMobileNumber(mobileNo);

		return s;
	}

}
