package com.capgemini.salesmanagement.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator {
public boolean validateProductCode(int code)
{
	String prodCode=Integer.toString(code);
	Pattern pattern=Pattern.compile("[0-9]{4}");
	Matcher match=pattern.matcher(prodCode);
	return match.matches();	
}
public boolean validateQuantity(int quantity)
{
	if(quantity>0 && quantity <5)
	{
		return true;
	}
	else
		return false;
}
public boolean validateCategory(String category)
{
	if(category.equalsIgnoreCase("Electronics") || category.equalsIgnoreCase("Toys"))
{
	return true;
}
	return false;
}
public boolean validateProductName(String category,String name)
{
	if((name.equalsIgnoreCase("TV") && category.equalsIgnoreCase("Electronics")) || (name.equalsIgnoreCase("Video Game") && category.equalsIgnoreCase("Electronics")) || (name.equalsIgnoreCase("iPhone") && category.equalsIgnoreCase("Electronics")))
	{
	return true;
	}
	else if((name.equalsIgnoreCase("Soft Toy") && category.equalsIgnoreCase("Toys")) || (name.equalsIgnoreCase("Telescope") && category.equalsIgnoreCase("Toys")) || (name.equalsIgnoreCase("Barbee Doll") && category.equalsIgnoreCase("Toys")))
	{
		return true;
	}
	else {
	return false;
	}
}
public boolean validatePrice(float price)
{
	if(price>200)
	{
		return true;
	}
	else
		return false;
}
}
