package com.capgemini.salesmanagement.bean;
//importing packages
import java.time.LocalDate;

public class Sales {
private int saleId; //variable declaration
private int prodCode;
private String productName;
private String description;
private String category;
private LocalDate saleDate;
private int quantity;
private float lineTotal;
public int getSaleId() {
	return saleId;
}
public Sales() {
	
}
//getter and setter methods
public void setSaleId(int saleId) {
	this.saleId = saleId;
}
public int getProdCode() {
	return prodCode;
}
public void setProdCode(int prodCode) {
	this.prodCode = prodCode;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public LocalDate getSaleDate() {
	return saleDate;
}
public void setSaleDate(LocalDate saleDate) {
	this.saleDate = saleDate;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public float getLineTotal() {
	return lineTotal;
}
public void setLineTotal(float lineTotal) {
	this.lineTotal = lineTotal;
}
//parameterized constructor
public Sales(int saleId, int prodCode, String productName, String description, String category, LocalDate dateString,
		int quantity, float lineTotal) {
	super();
	this.saleId = saleId;
	this.prodCode = prodCode;
	this.productName = productName;
	this.description = description;
	this.category = category;
	this.saleDate = dateString;
	this.quantity = quantity;
	this.lineTotal = lineTotal;
}

}
