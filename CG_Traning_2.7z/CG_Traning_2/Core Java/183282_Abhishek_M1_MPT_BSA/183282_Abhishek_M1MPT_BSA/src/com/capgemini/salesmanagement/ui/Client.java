package com.capgemini.salesmanagement.ui;
//importing the packages
import java.util.InputMismatchException;
import java.util.Scanner;
import com.capgemini.salesmanagement.bean.Sales;
import com.capgemini.salesmanagement.exception.ISaleException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {
	private static Sales acceptDetails() {
		int code,quantity;	//declaring the variables
		float price;
		String category,des,name;
		
		Sales sale=new Sales(); //created new instance of the sales class
		Scanner scanner=new Scanner(System.in);
		try {   //try catch block to check the format of product code
		System.out.println("Enter the product code: ");
		code=scanner.nextInt();
		sale.setProdCode(code);
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter valid product code\nProduct code can be number only");
		}
		
		try {  //try catch block to check the format of product quantity
		System.out.println("Enter the quantity: ");
		quantity=scanner.nextInt();
		sale.setQuantity(quantity);
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter valid quantiy\nIt can be number only");
		}
		
		try {    //try catch block to check the format of product category
			
		System.out.println("Product Category: ");
		category=scanner.next();
		sale.setCategory(category.trim());
		
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter valid category\nIt can be string only!");
		}
		try {		//try catch block to check the format of product name
			
			System.out.println("Product Name: ");
			name=scanner.next();
			sale.setProductName(name.trim());
			}
			catch(InputMismatchException e)
			{
				System.out.println("Enter valid product name\nIt can be string only!");
			}
		try {   //try catch block to check the format of product description
		System.out.println("Product Description: ");
		scanner.nextLine();
		des=scanner.nextLine();
		sale.setDescription(des);
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter valid product description\nProduct description can be string only!");
		}
		
		try {		//try catch block to check the format of product price
		System.out.println("Product Price (Rs): ");
		price=scanner.nextFloat();
		sale.setLineTotal(price);//assigning the temporary price
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter valid Price\nPrice can be numeric only!");
		}
		
		return sale;
		
	

	}
public static void main(String[] args) {
	do {		//do begin
		ISaleService saleService=new SaleService();
	Scanner sc=new Scanner(System.in);	//scanner class object creation
	System.out.println("1) Enter Product Details");
	System.out.println("2) Exit");
	System.out.println("Enter your choice");
	int choice=sc.nextInt();
	switch(choice)
	{
		case 1:
			Sales sale=new Sales();
			sale=acceptDetails();//calling the acceptDetails static method
		try {
			sale=saleService.addDetails(sale);//printing the bill
		System.out.println("Ordered Successfull!!");
		System.out.println("Sales id: "+sale.getSaleId());
		System.out.println("Product Code: "+sale.getProdCode());
		System.out.println("Product Name: "+sale.getProductName());
		System.out.println("Quantity: "+sale.getQuantity());
		System.out.println("Category:" +sale.getCategory());
		System.out.println("Date:" +sale.getSaleDate());
		System.out.println("Description: "+sale.getDescription());
		System.out.println("Quantity: "+sale.getQuantity());
		System.out.println("Line Total (Rs): "+sale.getLineTotal());
		} catch (ISaleException e) {
			System.out.println(e.getMessage());
		}
			break;
		case 2:
			sc.close();		//scanner object close
			System.exit(0);
			break;
		default: System.out.println("Enter valid choice"); //default message when invalid input is selected
			break;
	}//switch ends
	}//do ends
	while(true);//while ends
}
}
