package com.capgemini.salesmanagement.service;
import java.time.LocalDate;

import com.capgemini.salesmanagement.bean.Sales;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exception.ISaleException;

public class SaleService implements ISaleService{
	SaleDAO dao;
	DataValidator validator;//declaring the variables
public SaleService() {
	dao=new SaleDAO();	//initialization of the variables
	validator=new DataValidator();	
}
//method declaration of interface
@Override
public Sales addDetails(Sales s) throws ISaleException {
	//validation for product code
	if(!validator.validateProductCode(s.getProdCode()))
	{
		throw new ISaleException("Enter valid Product Code!\nProduct code should be a four digit number!");
	}
	//validation for validating quantity
	if(!validator.validateQuantity(s.getQuantity()))
	{
		throw new ISaleException("Enter valid Quantity!\nQuantity should be more than 0 and less than 5!");
	}
	//validation for validating category
	if(!validator.validateCategory(s.getCategory())) {
		throw new ISaleException("Enter valid Category!\nCategory should be either Electronics or Toys!");
	}
	//validation for validating product name
	if(!validator.validateProductName(s.getCategory(),s.getProductName())) {
		throw new ISaleException("Enter valid Category and name!");
	}
	//validation for validating price
	if(!validator.validatePrice(s.getLineTotal())) {
		throw new ISaleException("Enter valid Price!\nPrice should be greater than 200!");
	}
	//generation of random sale id
	int saleId=(int) (Math.random()*10000);
	s.setSaleId(saleId);
	//calculation to find the total cost of the product
	float totalCost=s.getQuantity()*s.getLineTotal();
	s.setLineTotal(totalCost);//re assigning the temparory price with the total cost..
	s.setSaleDate(LocalDate.now());
	return dao.addDetails(s);
}
}
