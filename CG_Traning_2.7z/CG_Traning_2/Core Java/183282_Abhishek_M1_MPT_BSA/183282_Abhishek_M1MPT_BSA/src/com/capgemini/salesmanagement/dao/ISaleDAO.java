package com.capgemini.salesmanagement.dao;

import com.capgemini.salesmanagement.bean.Sales;
import com.capgemini.salesmanagement.exception.ISaleException;

public interface ISaleDAO { 
	//methods declaration
public Sales addDetails(Sales s) throws ISaleException; 

}
