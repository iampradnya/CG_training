package com.capgemini.salesmanagement.dao;

import com.capgemini.salesmanagement.bean.Sales;
import com.capgemini.salesmanagement.exception.ISaleException;
import com.capgemini.salesmanagement.util.CollectionUtil;

/**
 * Author name:Pradnya Patil
 * @author ppati100
 *Mail Id:pradnya.f.patil@capgemini.com
 *Version:1.0
 *Description:Dao class to perform CRUD operations on hashmap
 *Date:!13-july-2019
 */

 
public class SaleDAO implements ISaleDAO{
	CollectionUtil collection;//variable declaration
public SaleDAO() { //constructor
	collection=new CollectionUtil();
}
//method declaration of interface
	@Override
	public Sales addDetails(Sales s) throws ISaleException {
		CollectionUtil.setCollection(s);
		return s;
		
	}

}
