package com.capgemini.salesmanagement.service;

import com.capgemini.salesmanagement.bean.Sales;
import com.capgemini.salesmanagement.exception.ISaleException;

public interface ISaleService {	//methods declaration
	public Sales addDetails(Sales s) throws ISaleException; 
}
