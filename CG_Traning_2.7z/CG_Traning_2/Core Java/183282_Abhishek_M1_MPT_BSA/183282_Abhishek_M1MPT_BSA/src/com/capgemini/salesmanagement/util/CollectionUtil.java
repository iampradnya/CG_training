package com.capgemini.salesmanagement.util;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.salesmanagement.bean.Sales;


public class CollectionUtil {
	public CollectionUtil() {
		
	}
	private static Map<Integer,Sales> sales=new HashMap<Integer,Sales>(); 
	static {
	sales.put(1010, new Sales(1010,1000,"iPhone","goodproduct","Electronics",LocalDate.now() , 2,10000));
	sales.put(1011, new Sales(1011, 1001, "Telescope", "children toys", "Toys",LocalDate.now(), 4,1000));
	}
	//This method will retrieve the sales details from the hashmap
	public static Map<Integer,Sales> getCollection(){
		return sales;
	}
	//This method will insert the sales details in the hashmap
	public static void setCollection(Sales sale) {
		sales.put(sale.getSaleId(), sale);
	}
	LocalDate h;

}
