package com.capgemini.salesmanagement.exception;

public class ISaleException extends Exception{
public ISaleException() {
super("some error occured...");
}
public ISaleException(String str)
{
super(str);	
}
}
