/*package com.capgemini.salesmanagement.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.salesmanagement.service.DataValidator;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

class ISaleTest {

	@Test
	void testProductName() {//test case for valid product name
		DataValidator validator=new DataValidator();
		assertEquals(true, validator.validateProductName("toys", "telescope"));
	}
	@Test
	void testProductCode() {//test case for valid product code
		DataValidator validator=new DataValidator();
		assertEquals(true, validator.validateProductCode(1234));
	}
	@Test
	void testProductQuantity() {//test case for valid product quantity
		DataValidator validator=new DataValidator();
		assertEquals(false, validator.validateQuantity(5));
	}
	@Test
	void testProductCategory() {//test case for valid product category
		DataValidator validator=new DataValidator();
		assertEquals(true, validator.validateCategory("Electronics"));
	}
	@Test
	void testProductPrice() {//test case for valid product price
		DataValidator validator=new DataValidator();
		assertEquals(false, validator.validatePrice(199));
	}

}*/
